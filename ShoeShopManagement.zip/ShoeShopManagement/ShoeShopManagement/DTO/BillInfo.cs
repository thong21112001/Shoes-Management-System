﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class BillInfo
    {
        private int billifId;
        private int billId;
        private int proId;
        private int quantity;
        private float price;
        private int status;

        public int BillifId { get => billifId; set => billifId = value; }
        public int BillId { get => billId; set => billId = value; }
        public int ProId { get => proId; set => proId = value; }
        public int Quantity { get => quantity; set => quantity = value; }
        public float Price { get => price; set => price = value; }
        public int Status { get => status; set => status = value; }

        public BillInfo(int billifId, int billId, int proId, int quantity, float price, int status)
        {
            this.BillifId = billifId;
            this.BillId = billId;
            this.ProId = proId;
            this.Quantity = quantity;
            this.Price = price;
            this.Status = status;
        }

        public BillInfo(DataRow row)
        {
            this.BillifId = (int)row["billifId"];
            this.BillId = (int)row["billId"];
            this.ProId = (int)row["proId"];
            this.Quantity = (int)row["quantity"];
            this.Price = (float)Convert.ToDouble(row["price"].ToString());
            this.Status = (int)row["status"];
        }
    }
}
