﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class Supplier
    {
        private int supId;
        private string supName;
        private string supAddress;
        private string phoneNumber;
        private string email;
        private int status;

        public int SupId { get => supId; set => supId = value; }
        public string SupName { get => supName; set => supName = value; }
        public string SupAddress { get => supAddress; set => supAddress = value; }
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public string Email { get => email; set => email = value; }
        public int Status { get => status; set => status = value; }

        public Supplier(int supId, string supName, string supAddress, string phoneNumber, string email, int status)
        {
            this.SupId = supId;
            this.SupName = supName;
            this.SupAddress = supAddress;
            this.PhoneNumber = phoneNumber;
            this.Email = email;
            this.Status = status;
        }

        public Supplier(DataRow row)
        {
            this.SupId = (int)row["supId"];
            this.SupName = row["supName"].ToString();
            this.SupAddress = row["supAddress"].ToString();
            this.PhoneNumber = row["phoneNumber"].ToString();
            this.Email = row["email"].ToString();
            this.Status = (int)row["status"];
        }
    }
}
