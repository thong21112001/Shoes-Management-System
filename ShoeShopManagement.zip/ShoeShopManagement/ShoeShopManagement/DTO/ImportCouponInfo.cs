﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class ImportCouponInfo
    {
        private int imcIdInFo;
        private int imcId;
        private int quantity;
        private int prodId;
        private int status;

        public int ImcIdInFo { get => imcIdInFo; set => imcIdInFo = value; }
        public int ImcId { get => imcId; set => imcId = value; }
        public int Quantity { get => quantity; set => quantity = value; }
        public int ProdId { get => prodId; set => prodId = value; }
        public int Status { get => status; set => status = value; }

        public ImportCouponInfo(int imcIdInFo, int imcId, int quantity, int prodId, int status)
        {
            this.ImcIdInFo = imcIdInFo;
            this.ImcId = imcId;
            this.Quantity = quantity;
            this.ProdId = prodId;
            this.Status = status;
        }

        public ImportCouponInfo(DataRow row)
        {
            this.ImcIdInFo = (int)row["ImcIdInFo"];
            this.ImcId = (int)row["imcId"];
            this.Quantity = (int)row["quantity"];
            this.ProdId = (int)row["prodId"];
            this.Status = (int)row["status"];
        }
    }
}
