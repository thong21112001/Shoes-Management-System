﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class Product
    {
        private int prodId;
        private string nameSP;
        private float price;
        private byte[] image;
        private int cateId;
        private int supId;
        private int quantity;
        private int status;

        public int ProdId { get => prodId; set => prodId = value; }
        public string NameSP { get => nameSP; set => nameSP = value; }
        public float Price { get => price; set => price = value; }
        public byte[] Image { get => image; set => image = value; }
        public int CateId { get => cateId; set => cateId = value; }
        public int SupId { get => supId; set => supId = value; }
        public int Quantity { get => quantity; set => quantity = value; }
        public int Status { get => status; set => status = value; }

        public Product(int prodId, string nameSP, float price, byte[] image, int cateId, int supId, int quantity, int status)
        {
            this.ProdId = prodId;
            this.NameSP = nameSP;
            this.Price = price;
            this.Image = image;
            this.CateId = cateId;
            this.SupId = supId;
            this.Quantity = quantity;
            this.Status = status;
        }

        public Product(DataRow row)
        {
            this.ProdId = (int)row["prodId"];
            this.NameSP = row["nameSP"].ToString();
            this.Price = (float)Convert.ToDouble(row["price"].ToString());
            this.Image = image;
            this.CateId = (int)row["cateId"];
            this.SupId = (int)row["supId"];
            this.Quantity = (int)row["quantity"];
            this.Status = (int)row["status"];
        }
    }
}
