﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class ImportCoupon
    {
        private int imcId;
        private DateTime? checkDateImport;
        private int supId;
        private int usId;
        private int typeImc;
        private int status;

        public int ImcId { get => imcId; set => imcId = value; }
        public DateTime? CheckDateImport { get => checkDateImport; set => checkDateImport = value; }
        public int SupId { get => supId; set => supId = value; }
        public int UsId { get => usId; set => usId = value; }
        public int TypeImc { get => typeImc; set => typeImc = value; }
        public int Status { get => status; set => status = value; }

        public ImportCoupon(int imcId, DateTime? checkDateImport, int supId, int usId, int typeImc, int status)
        {
            this.ImcId = imcId;
            this.CheckDateImport = checkDateImport;
            this.SupId = supId;
            this.UsId = usId;
            this.TypeImc = typeImc;
            this.Status = status;
        }

        public ImportCoupon(DataRow row)
        {
            this.ImcId = (int)row["usId"];

            //voi truong hop bang null thi kiem tra
            var checkDate = row["checkDateImport"];
            if (checkDate.ToString() != "")
            {
                this.CheckDateImport = (DateTime?)checkDate;
            }

            this.SupId = (int)row["supId"];
            this.UsId = (int)row["usId"];
            this.TypeImc = (int)row["typeImc"];
            this.Status = (int)row["status"];
        }
    }
}
