﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class Customer
    {
        private int cusId;
        private string name;
        private string address;
        private string phoneNumber;
        private int status;

        public int CusId { get => cusId; set => cusId = value; }
        public string Name { get => name; set => name = value; }
        public string Address { get => address; set => address = value; }
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public int Status { get => status; set => status = value; }

        public Customer(int cusId, string name, string address, string phoneNumber, int status)
        {
            this.CusId = cusId;
            this.Name = name;
            this.Address = address;
            this.PhoneNumber = phoneNumber;
            this.Status = status;
        }

        public Customer(DataRow row)
        {
            this.CusId = (int)row["cusId"];
            this.Name = row["name"].ToString();
            this.Address = row["address"].ToString();
            this.PhoneNumber = row["phoneNumber"].ToString();
            this.Status = (int)row["status"];
        }
    }
}
