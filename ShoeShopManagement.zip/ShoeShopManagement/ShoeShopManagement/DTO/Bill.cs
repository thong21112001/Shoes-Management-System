﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class Bill
    {
        private int billId;
        private int usId;
        private int cusId;
        private DateTime? dateOfPayment;
        private float totalPrice;
        private int status;

        public int BillId { get => billId; set => billId = value; }
        public int UsId { get => usId; set => usId = value; }
        public int CusId { get => cusId; set => cusId = value; }
        public DateTime? DateOfPayment { get => dateOfPayment; set => dateOfPayment = value; }
        public float TotalPrice { get => totalPrice; set => totalPrice = value; }
        public int Status { get => status; set => status = value; }

        public Bill(int billId, int usId, int cusId, DateTime? dateOfPayment, float totalPrice, int status)
        {
            this.BillId = billId;
            this.UsId = usId;
            this.CusId = cusId;
            this.DateOfPayment = dateOfPayment;
            this.TotalPrice = totalPrice;
            this.Status = status;
        }

        public Bill(DataRow row)
        {
            this.BillId = (int)row["billId"];
            this.UsId = (int)row["usId"];
            this.CusId = (int)row["cusId"];

            //voi truong hop bang null thi kiem tra
            var checkDate = row["dateOfPayment"];
            if (checkDate.ToString() != "")
            {
                this.dateOfPayment = (DateTime?)checkDate;
            }

            this.TotalPrice = (float)Convert.ToDouble(row["totalPrice"].ToString());
            this.Status = (int)row["status"];
        }
    }
}
