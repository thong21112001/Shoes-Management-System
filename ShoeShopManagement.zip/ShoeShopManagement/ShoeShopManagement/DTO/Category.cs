﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DTO
{
    public class Category
    {
        private int cateId;
        private string nameCate;
        private int status;

        public int CateId { get => cateId; set => cateId = value; }
        public string NameCate { get => nameCate; set => nameCate = value; }
        public int Status { get => status; set => status = value; }

        public Category(int cateId, string nameCate, int status)
        {
            this.CateId = cateId;
            this.NameCate = nameCate;
            this.Status = status;
        }

        public Category(DataRow row)
        {
            this.CateId = (int)row["cateId"];
            this.NameCate = row["nameCate"].ToString();
            this.Status = (int)row["status"];
        }
    }
}
