﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ShoeShopManagement.DTO
{
    public class Account
    {
        private int usId;
        private string username;
        private string password;
        private int typeAccount;
        private string displayName;
        private string email;
        private int status;

        public int UsId { get => usId; set => usId = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public int TypeAccount { get => typeAccount; set => typeAccount = value; }
        public string DisplayName { get => displayName; set => displayName = value; }
        public string Email { get => email; set => email = value; }
        public int Status { get => status; set => status = value; }

        public Account(int usId, string username, string password, int typeAccount, string displayName, string email, int status)
        {
            this.UsId = usId;
            this.Username = username;
            this.Password = password;
            this.TypeAccount = typeAccount;
            this.DisplayName = displayName;
            this.Email = email;
            this.Status = status;
        }

        public Account(DataRow row)
        {
            this.UsId = (int)row["usId"];
            this.Username = row["username"].ToString();
            this.Password = row["password"].ToString();
            this.TypeAccount = (int)row["typeAccount"];
            this.DisplayName = row["displayName"].ToString();
            this.Email = row["email"].ToString();
            this.Status = (int)row["status"];
        }
    }
}
