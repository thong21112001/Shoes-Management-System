﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmCTHoaDon : Form
    {
        int idNhapKho;
        public frmCTHoaDon(int idNhapKho)
        {
            InitializeComponent();
            this.idNhapKho = idNhapKho;
        }

        private void frmCTHoaDon_Load(object sender, EventArgs e)
        {
            gvBill.DataSource = BillInfoDAL.Instance.GetBillCT(idNhapKho);
            LoadGridView();
            lbIdPN.Text = idNhapKho.ToString();
        }

        #region Methods
        private void LoadGridView()
        {
            gvBill.Columns[0].HeaderText = "Tên SP";
            gvBill.Columns[1].HeaderText = "Số Lượng";
            gvBill.Columns[2].HeaderText = "Đơn Giá";
            foreach (DataGridViewColumn item in gvBill.Columns)
            {
                item.DividerWidth = 1;
            }
            gvBill.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvBill.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvBill.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
        #endregion

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
