﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmPhieuNhap : Form
    {
        frmPhieuNhap frmImport;
        private int role;

        public frmPhieuNhap()
        {
            InitializeComponent();
            LoadALL();
        }

        public void frmPhieuNhap_Load(object sender, EventArgs e)
        {
            LoadALL();
        }

        #region Methods
        //Hàm LoadALL
        public void LoadALL()
        {
            LoadGridView(frmImport);
            SetValue(true, false);
            LoadUser();
            LoadSupplier();
        }

        //Hàm Reset trường data
        public void ResetTextALL(frmPhieuNhap frmImport)
        {
            txtIdPN.Text = null;
            txtDay.Text = null;
            cbUserID.Text = null;
            cbSupplierID.Text = null;
        }

        //Hàm set value
        private void SetValue(bool param, bool isLoad)
        {
            txtIdPN.Text = null;
            txtDay.Text = null;
            txtDay.ReadOnly = true;
            cbUserID.Text = null;
            cbSupplierID.Text = null;

            btnThemPN.Enabled = param;
            btnChiTietPN.Enabled = param;
            btnListImportCoupon.Enabled = param;

            radChuaThanhToan.Enabled = param;
            radDaThanhToan.Enabled = param;

            if (isLoad)
            {
                btnSuaPN.Enabled = false;
                btnXoaPN.Enabled = false;
            }
            else
            {
                btnSuaPN.Enabled = !param;
                btnXoaPN.Enabled = !param;
            }

            radChuaThanhToan.Checked = true;
            radDaThanhToan.Visible = false;
        }
        //Load dữ liệu lên combo Box cbUserID
        void LoadUser()
        {
            try
            {
                string sql = "Select * from dbo.tblAccount Where TypeAccount = 1 and Status = 1";
                cbUserID.DataSource = DataProvider.Instance.ExQuery(sql);
                cbUserID.DisplayMember = "UserName";
                cbUserID.ValueMember = "UsId";
            }
            catch (Exception)
            {
                MessageBox.Show("Load dữ liệu không được", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        void LoadSupplier()
        {
            try
            {
                string sql = "Select * from dbo.tblSupplier Where Status = 1";
                cbSupplierID.DataSource = DataProvider.Instance.ExQuery(sql);
                cbSupplierID.DisplayMember = "SupName";
                cbSupplierID.ValueMember = "SupId";
            }
            catch (Exception)
            {
                MessageBox.Show("Load dữ liệu không được", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        //Hàm load lên data GirdView
        public void LoadGridView(frmPhieuNhap frmImport)
        {
            dgvImportCoupon.DataSource = ImportCouponDAL.Instance.GetImportCoupon();

            dgvImportCoupon.Columns[0].HeaderText = "Mã phiếu nhập";
            dgvImportCoupon.Columns[1].HeaderText = "Ngày nhập";
            dgvImportCoupon.Columns[2].HeaderText = "Nhà cung cấp";
            dgvImportCoupon.Columns[3].HeaderText = "Người nhập";
            dgvImportCoupon.Columns[4].HeaderText = "Trạng thái";

            foreach (DataGridViewColumn item in dgvImportCoupon.Columns)
                item.DividerWidth = 1;

            dgvImportCoupon.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvImportCoupon.Columns[1].DefaultCellStyle.Format = "d";

            dgvImportCoupon.Columns[2].Visible = false;
            dgvImportCoupon.Columns[3].Visible = false;
            dgvImportCoupon.Columns[4].Visible = false;
        }
        #endregion





        #region Events
        private void btnThemPN_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thêm phiếu nhập này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (cbSupplierID.Text == "" || cbUserID.Text == "" || txtDay.Text == "")
                        MessageBox.Show("Không bỏ trống dữ liệu !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else
                    {
                        if (radChuaThanhToan.Checked == true)
                        {
                            role = Convert.ToInt32(radChuaThanhToan.Checked);
                        }
                        else
                        {
                            role = 0;
                        }
                        DateTime loadedDate = DateTime.ParseExact(txtDay.Text, "d", null);
                        int idUser = Convert.ToInt32(cbUserID.SelectedValue.ToString());
                        int idSuplier = Convert.ToInt32(cbSupplierID.SelectedValue.ToString());
                        int statusPN = 1;

                        ImportCouponDAL.Instance.InsertImportCoupon(loadedDate, idSuplier, idUser, role, statusPN);
                        MessageBox.Show("Thêm phiếu nhập thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView(frmImport);
                        ResetTextALL(frmImport);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm phiếu nhập thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnSuaPN_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn cập nhập phiếu nhập này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (cbSupplierID.Text == "" || cbUserID.Text == "")
                        MessageBox.Show("Không bỏ trống dữ liệu !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else
                    {
                        int idPN = Convert.ToInt32(txtIdPN.Text);
                        DateTime loadedDate = DateTime.ParseExact(txtDay.Text, "d", null);
                        int idUser = Convert.ToInt32(cbUserID.SelectedValue.ToString());
                        int idSuplier = Convert.ToInt32(cbSupplierID.SelectedValue.ToString());

                        ImportCouponDAL.Instance.UpdateImportCoupon(loadedDate, idSuplier, idUser, idPN);
                        MessageBox.Show("Sửa phiếu nhập thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView(frmImport);
                        ResetTextALL(frmImport);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Sửa phiếu nhập thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnXoaPN_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn xóa phiếu nhập này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdPN.Text == "")
                    {
                        MessageBox.Show("Xóa phiếu nhập thất bại có thể thiếu id sản phẩm \n Bấm vào bảng phía dưới để lấy id sản phẩm!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int idPN = Convert.ToInt32(txtIdPN.Text);

                        ImportCouponDAL.Instance.DelImportCoupon(idPN);
                        MessageBox.Show("Xóa phiếu nhập thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView(frmImport);
                        ResetTextALL(frmImport);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa phiếu nhập thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnResetPN_Click(object sender, EventArgs e)
        {
            SetValue(true, false);
            LoadGridView(frmImport);
            radChuaThanhToan.Visible = true;
            radChuaThanhToan.Checked = true;
            radDaThanhToan.Visible = false;
        }

        private void btnListImportCoupon_Click(object sender, EventArgs e)
        {
            if (txtIdPN.Text != "")
            {
                int idPNCT = Convert.ToInt32(txtIdPN.Text);
                frmDSPhieuNhap i4 = new frmDSPhieuNhap(idPNCT);
                i4.ShowDialog();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn 1 phiếu nhập kho trước!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        private void btnChiTietPN_Click(object sender, EventArgs e)
        {
            if (txtIdPN.Text != "")
            {
                int idPNCT = Convert.ToInt32(txtIdPN.Text);
                frmCTPhieuNhap i4 = new frmCTPhieuNhap(idPNCT);
                i4.ShowDialog();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn 1 phiếu nhập kho trước!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        private void dgvImportCoupon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvImportCoupon.Rows.Count > 0)
            {
                CheckDateImport.Format = DateTimePickerFormat.Custom;
                CheckDateImport.CustomFormat = "dd/MM/yyyy";
                txtDay.Text = CheckDateImport.CustomFormat;
                txtDay.ReadOnly = false;

                btnSuaPN.Enabled = true;
                btnXoaPN.Enabled = true;
                btnThemPN.Enabled = false;

                txtIdPN.Text = dgvImportCoupon.CurrentRow.Cells[0].Value.ToString();
                CheckDateImport.Text = dgvImportCoupon.CurrentRow.Cells[1].Value.ToString();
                cbSupplierID.SelectedValue = dgvImportCoupon.CurrentRow.Cells[2].Value.ToString();
                cbUserID.SelectedValue = dgvImportCoupon.CurrentRow.Cells[3].Value.ToString();

                txtDay.Text = CheckDateImport.Value.ToString("dd/MM/yyyy");

                string Vt;
                Vt = dgvImportCoupon.CurrentRow.Cells[4].Value.ToString();

                if (Vt == "1")
                {
                    radChuaThanhToan.Checked = true;
                    radDaThanhToan.Visible = false;
                    radChuaThanhToan.Visible = true;
                    btnChiTietPN.Enabled = true;
                    btnListImportCoupon.Enabled = false;
                }
                else
                {
                    radDaThanhToan.Checked = true;
                    radChuaThanhToan.Visible = false;
                    radDaThanhToan.Visible = true;
                    btnSuaPN.Enabled = false;
                    btnChiTietPN.Enabled = false;
                    btnListImportCoupon.Enabled = true;
                }
            }
        }
        private void CheckDateImport_ValueChanged(object sender, EventArgs e)
        {
            CheckDateImport.Format = DateTimePickerFormat.Custom;
            CheckDateImport.CustomFormat = "dd/MM/yyyy";
            txtDay.Text = CheckDateImport.CustomFormat;
            txtDay.Text = CheckDateImport.Value.ToString("dd/MM/yyyy");
        }

        private void btnDSXoa_Click(object sender, EventArgs e)
        {
            dgvImportCoupon.DataSource = ImportCouponDAL.Instance.GetImportCouponDel();

            dgvImportCoupon.Columns[0].HeaderText = "Mã phiếu nhập";
            dgvImportCoupon.Columns[1].HeaderText = "Ngày nhập";
            dgvImportCoupon.Columns[2].HeaderText = "Nhà cung cấp";
            dgvImportCoupon.Columns[3].HeaderText = "Người nhập";
            dgvImportCoupon.Columns[4].HeaderText = "Trạng thái";

            foreach (DataGridViewColumn item in dgvImportCoupon.Columns)
                item.DividerWidth = 1;

            dgvImportCoupon.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvImportCoupon.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvImportCoupon.Columns[1].DefaultCellStyle.Format = "d";

            dgvImportCoupon.Columns[2].Visible = false;
            dgvImportCoupon.Columns[3].Visible = false;
            dgvImportCoupon.Columns[4].Visible = false;
        }

        private void btnPhucHoi_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn khôi phục dữ liệu lại không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    int id = Convert.ToInt32(txtPhucHoi.Text);

                    if (txtPhucHoi.Text == "")
                    {
                        MessageBox.Show("Nhập dữ liệu cần khôi phục,không được để trống", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else if (id != ImportCouponDAL.Instance.GetIdPN(id))
                    {
                        MessageBox.Show("Mã phiếu nhập không tồn tại", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        ProductsDAL.Instance.PhucHoi(id);
                        MessageBox.Show("Phục hồi thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        SetValue(true, false);
                        LoadGridView(frmImport);
                        txtPhucHoi.Text = "";
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu cần khôi phục thất bại có thể thiếu hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }
        #endregion
    }
}
