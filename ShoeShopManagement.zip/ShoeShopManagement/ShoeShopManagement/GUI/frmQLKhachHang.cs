﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmQLKhachHang : Form
    {
        frmQLKhachHang frmQLKH;

        public frmQLKhachHang()
        {
            InitializeComponent();
            LoadALL();
        }

        public void frmQLKhachHang_Load(object sender, EventArgs e)
        {
            LoadALL();
        }

        #region Methods
        //Hàm LoadALL
        void LoadALL()
        {
            LoadGridView();
            SetValue(true, false);
        }

        //Hàm Reset trường data
        public void ResetTextALL(frmQLKhachHang frmKH)
        {
            txtIdKH.Text = null;
            txtNameKH.Text = null;
            txtDiaChiKH.Text = null;
            txtSDTKH.Text = null;
        }

        //Hàm set value
        private void SetValue(bool param, bool isLoad)
        {
            txtIdKH.Text = null;
            txtNameKH.Text = null;
            txtDiaChiKH.Text = null;
            txtSDTKH.Text = null;
            txtSearch.Text = null;

            btnThemKH.Enabled = param;

            if (isLoad)
            {
                btnSuaKH.Enabled = false;
                btnXoaKH.Enabled = false;
            }
            else
            {
                btnSuaKH.Enabled = !param;
                btnXoaKH.Enabled = !param;
            }
        }

        //Hàm load lên data GirdView
        private void LoadGridView()
        {
            dgvCustomers.DataSource = CustomersDAL.Instance.GetCustomers();

            dgvCustomers.Columns[0].HeaderText = "Mã khách hàng";
            dgvCustomers.Columns[1].HeaderText = "Tên khách hàng";
            dgvCustomers.Columns[2].HeaderText = "Địa chỉ";
            dgvCustomers.Columns[3].HeaderText = "Số điện thoại";

            foreach (DataGridViewColumn item in dgvCustomers.Columns)
            {
                item.DividerWidth = 1;
            }

            dgvCustomers.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvCustomers.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvCustomers.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvCustomers.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvCustomers.Columns[0].Visible = false;
        }


        #endregion





        #region Events
        private void btnThemKH_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thêm khách hàng này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtNameKH.Text == "" || txtSDTKH.Text == "" || txtDiaChiKH.Text == "")
                        MessageBox.Show("Không bỏ trống các trường !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else
                    {
                        string nameKH = txtNameKH.Text;
                        string sdt = txtSDTKH.Text;
                        string diachi = txtDiaChiKH.Text;
                        int statusCus = 1;

                        CustomersDAL.Instance.InsertCustomers(nameKH, diachi, sdt, statusCus);
                        MessageBox.Show("Thêm khách hàng thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmQLKH);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm khách hàng thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnSuaKH_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn cập nhập khách hàng này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtNameKH.Text == "" || txtSDTKH.Text == "" || txtDiaChiKH.Text == "")
                    {
                        MessageBox.Show("Sửa khách hàng thất bại có thể thiếu các ô bị trống hoặc định dạng sai \n Bấm bảng bên dưới để lấy dữ liệu!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtIdKH.Text);
                        string nameKH = txtNameKH.Text;
                        string sdt = txtSDTKH.Text;
                        string diachi = txtDiaChiKH.Text;

                        CustomersDAL.Instance.UpdateCustomers(id, nameKH, sdt, diachi);
                        MessageBox.Show("Sửa khách hàng thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmQLKH);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Sửa khách hàng thất bại có thể thiếu các ô bị trống hoặc định dạng sai \n Bấm bảng bên dưới để lấy dữ liệu!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnXoaKH_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn xóa khách hàng này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdKH.Text == "")
                    {
                        MessageBox.Show("Xóa khách hàng thất bại có thể thiếu id tài khoản \n Bấm vào bảng phía dưới để lấy id tài khoản!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtIdKH.Text);

                        CustomersDAL.Instance.DelCustomers(id);
                        MessageBox.Show("Xóa khách hàng thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmQLKH);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa khách hàng thất bại có thể thiếu id tài khoản hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnResetKH_Click(object sender, EventArgs e)
        {
            SetValue(true, false);
            LoadGridView();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string name;
            name = txtSearch.Text.Trim();
            if (name == "")
            {
                frmQLKhachHang_Load(sender, e);
                txtSearch.Focus();
            }
            else
            {
                DataTable data = CustomersDAL.Instance.SearchCustomers(name);
                dgvCustomers.DataSource = data;
            }
        }

        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCustomers.Rows.Count > 0)
            {
                btnSuaKH.Enabled = true;
                btnXoaKH.Enabled = true;
                btnThemKH.Enabled = false;

                txtIdKH.Text = dgvCustomers.CurrentRow.Cells[0].Value.ToString();
                txtNameKH.Text = dgvCustomers.CurrentRow.Cells[1].Value.ToString();
                txtDiaChiKH.Text = dgvCustomers.CurrentRow.Cells[2].Value.ToString();
                txtSDTKH.Text = dgvCustomers.CurrentRow.Cells[3].Value.ToString();
            }
        }
        private void btnPhucHoi_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn khôi phục dữ liệu lại không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtPhucHoi.Text == "")
                    {
                        MessageBox.Show("Nhập dữ liệu cần khôi phục,không được để trống", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else if (txtPhucHoi.Text != CustomersDAL.Instance.GetSDT(txtPhucHoi.Text))
                    {
                        MessageBox.Show("Số điện thoại không tồn tại", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string ph = txtPhucHoi.Text;
                        CustomersDAL.Instance.PhucHoiKH(ph);
                        MessageBox.Show("Phục hồi thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        SetValue(true, false);
                        txtPhucHoi.Text = "";
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu cần khôi phục thất bại có thể thiếu hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }
        #endregion

        private void btnDSXoa_Click(object sender, EventArgs e)
        {
            dgvCustomers.DataSource = CustomersDAL.Instance.GetCustomersDel();

            dgvCustomers.Columns[0].HeaderText = "Mã khách hàng";
            dgvCustomers.Columns[1].HeaderText = "Tên khách hàng";
            dgvCustomers.Columns[2].HeaderText = "Địa chỉ";
            dgvCustomers.Columns[3].HeaderText = "Số điện thoại";

            foreach (DataGridViewColumn item in dgvCustomers.Columns)
            {
                item.DividerWidth = 1;
            }

            dgvCustomers.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvCustomers.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvCustomers.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvCustomers.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvCustomers.Columns[0].Visible = false;
        }
    }
}
