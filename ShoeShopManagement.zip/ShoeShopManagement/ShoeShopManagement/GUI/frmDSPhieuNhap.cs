﻿using ShoeShopManagement.DAL;
using ShoeShopManagement.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmDSPhieuNhap : Form
    {
        int idNhapKho;

        public frmDSPhieuNhap(int idNhapKho)
        {
            InitializeComponent();
            this.idNhapKho = idNhapKho;

        }

        private void frmDSPhieuNhap_Load(object sender, EventArgs e)
        {
            gvListPN.DataSource = ImportCouponDAL.Instance.GetListPNCT(idNhapKho);
            LoadGridView();
            lbIdPN.Text = idNhapKho.ToString();
        }

        #region Methods
        private void LoadGridView()
        {
            gvListPN.Columns[0].HeaderText = "Mã Phiếu Nhập";
            gvListPN.Columns[1].HeaderText = "Tên Sản Phẩm";
            gvListPN.Columns[2].HeaderText = "Số Lượng Nhập";
            gvListPN.Columns[3].HeaderText = "Nhà Cung Cấp";
            gvListPN.Columns[4].HeaderText = "Người Nhập";
            gvListPN.Columns[5].HeaderText = "Ngày Nhập";

            foreach (DataGridViewColumn item in gvListPN.Columns)
            {
                item.DividerWidth = 1;
            }
            gvListPN.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvListPN.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvListPN.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvListPN.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvListPN.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvListPN.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
        #endregion

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
