﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmSanPham : Form
    {
        frmSanPham frmSaP;
        private string fileAddress;
        private byte[] img;

        public frmSanPham()
        {
            InitializeComponent();
            LoadALL();
        }

        public void frmSanPham_Load(object sender, EventArgs e)
        {
            LoadALL();
        }


        #region Methods
        //Hàm LoadALL
        void LoadALL()
        {
            LoadGridView(frmSaP);
            SetValue(true, false);
            LoadCategory();
            LoadSupplier();
        }

        //Hàm Reset trường data
        public void ResetTextALL(frmSanPham frmSP)
        {
            txtIdSP.Text = null;
            txtNameProduct.Text = null;
            txtPrice.Text = null;
            txtSearch.Text = null;
            cbCateID.Text = null;
            cbSupplierID.Text = null;
            picBox.Image = null;
            txtQuantity.Text = null;
        }

        //Hàm set value
        private void SetValue(bool param, bool isLoad)
        {
            txtIdSP.Text = null;
            txtNameProduct.Text = null;
            txtPrice.Text = null;
            txtSearch.Text = null;
            txtQuantity.Text = null;
            cbCateID.Text = null;
            cbSupplierID.Text = null;

            btnThemSP.Enabled = param;
            picBox.Image = null;

            if (isLoad)
            {
                btnSuaSP.Enabled = false;
                btnXoaSP.Enabled = false;
            }
            else
            {
                btnSuaSP.Enabled = !param;
                btnXoaSP.Enabled = !param;
            }
        }

        //Load dữ liệu lên combo Box cbCateID
        void LoadCategory()
        {
            try
            {
                string sql = "Select * from dbo.tblCategory where Status = 1";
                cbCateID.DataSource = DataProvider.Instance.ExQuery(sql);
                cbCateID.DisplayMember = "NameCate";
                cbCateID.ValueMember = "CateId";
            }
            catch (Exception)
            {
                MessageBox.Show("Load dữ liệu không được", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        void LoadSupplier()
        {
            try
            {
                string sql = "Select * from dbo.tblSupplier where Status = 1";
                cbSupplierID.DataSource = DataProvider.Instance.ExQuery(sql);
                cbSupplierID.DisplayMember = "SupName";
                cbSupplierID.ValueMember = "SupId";
            }
            catch (Exception)
            {
                MessageBox.Show("Load dữ liệu không được", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        //Hàm load lên data GirdView
        public void LoadGridView(frmSanPham frmSP)
        {
            dgvProduct.DataSource = ProductsDAL.Instance.ListOfProduct();

            dgvProduct.Columns[0].HeaderText = "Mã hàng";
            dgvProduct.Columns[1].HeaderText = "Tên hàng";
            dgvProduct.Columns[2].HeaderText = "Đơn giá";
            dgvProduct.Columns[3].HeaderText = "Hình ảnh";
            dgvProduct.Columns[4].HeaderText = "Mã danh mục";
            dgvProduct.Columns[5].HeaderText = "Mã nhà cung cấp";
            dgvProduct.Columns[6].HeaderText = "Số lượng tồn";

            foreach (DataGridViewColumn item in dgvProduct.Columns)
                item.DividerWidth = 1;

            DataGridViewImageColumn imgCol = new DataGridViewImageColumn();
            imgCol = (DataGridViewImageColumn)dgvProduct.Columns[3];
            imgCol.ImageLayout = DataGridViewImageCellLayout.Zoom;

            dgvProduct.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvProduct.Columns[0].Visible = false;
            dgvProduct.Columns[4].Visible = false;
            dgvProduct.Columns[5].Visible = false;
        }

        //Trả về dữ liệu textbox Đơn gián bán là int thay vì string
        private bool CheckIsNummber(string text)
        {
            return int.TryParse(text, out int s);
        }

        //Xử lý ảnh
        private Image CloneImage(string path)
        {
            Image result;
            using (Bitmap original = new Bitmap(path))
            {
                result = (Bitmap)original.Clone();

            };
            return result;
        }

        private void OpenImage()
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Pictures files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png)|*.jpg; *.jpeg; *.jpe; *.jfif; *.png|All files (*.*)|*.*";
            open.Title = "Chọn ảnh";
            if (open.ShowDialog() == DialogResult.OK)
            {
                fileAddress = open.FileName;
                picBox.Image = CloneImage(fileAddress);
                picBox.ImageLocation = fileAddress;
                img = ImageToByteArray(picBox);
            }
        }

        private byte[] ImageToByteArray(PictureBox pictureBox)
        {
            MemoryStream memoryStream = new MemoryStream();
            pictureBox.Image.Save(memoryStream, pictureBox.Image.RawFormat);
            return memoryStream.ToArray();
        }

        //End Xử lý ảnh
        #endregion



        #region Events
        private void btnThemSP_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thêm sản phẩm này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtNameProduct.Text == "")
                        MessageBox.Show("Không bỏ trống tên !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else if (!CheckIsNummber(txtPrice.Text))
                        MessageBox.Show("Đơn giá là số !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else if (picBox.Image == null)
                        MessageBox.Show("Vui lòng thêm ảnh !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else
                    {
                        txtQuantity.Text = "0";
                        string nameSP = txtNameProduct.Text;
                        float price = float.Parse(txtPrice.Text);
                        int quantity = Convert.ToInt32(txtQuantity.Text);
                        int idCate = Convert.ToInt32(cbCateID.SelectedValue.ToString());
                        int idSuplier = Convert.ToInt32(cbSupplierID.SelectedValue.ToString());
                        int statusP = 1;

                        ProductsDAL.Instance.InsertProduct(nameSP, price, ImageToByteArray(picBox), idCate, idSuplier, quantity, statusP);
                        MessageBox.Show("Thêm sản phẩm thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView(frmSaP);
                        ResetTextALL(frmSaP);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm sản phẩm thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnSuaSP_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn cập nhập sản phẩm này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtNameProduct.Text == "")
                        MessageBox.Show("Không bỏ trống tên !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else if (!CheckIsNummber(txtPrice.Text))
                        MessageBox.Show("Đơn giá là số !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else if (picBox.Image == null)
                        MessageBox.Show("Vui lòng thêm ảnh !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else
                    {
                        int idSP = Convert.ToInt32(txtIdSP.Text);
                        string nameSP = txtNameProduct.Text;
                        float price = float.Parse(txtPrice.Text);
                        int idCate = Convert.ToInt32(cbCateID.SelectedValue.ToString());
                        int idSuplier = Convert.ToInt32(cbSupplierID.SelectedValue.ToString());

                        ProductsDAL.Instance.UpdateProduct(nameSP, price, ImageToByteArray(picBox), idCate, idSuplier, idSP);
                        MessageBox.Show("Sửa sản phẩm thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView(frmSaP);
                        ResetTextALL(frmSaP);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Sửa sản phẩm thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnXoaSP_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn xóa sản phẩm này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdSP.Text == "")
                    {
                        MessageBox.Show("Xóa sản phẩm thất bại có thể thiếu id sản phẩm \n Bấm vào bảng phía dưới để lấy id sản phẩm!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtIdSP.Text);

                        ProductsDAL.Instance.DelProduct(id);
                        MessageBox.Show("Xóa sản phẩm thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView(frmSaP);
                        ResetTextALL(frmSaP);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa sản phẩm thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnResetSP_Click(object sender, EventArgs e)
        {
            SetValue(true, false);
            LoadGridView(frmSaP);
        }

        private void btnAddPic_Click(object sender, EventArgs e)
        {
            OpenImage();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string name;
            name = txtSearch.Text.Trim();
            if (name == "")
            {
                frmSanPham_Load(sender, e);
                txtSearch.Focus();
            }
            else
            {
                DataTable data = ProductsDAL.Instance.SearchProducts(name);
                dgvProduct.DataSource = data;
            }
        }

        private void dgvProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvProduct.Rows.Count > 0)
            {
                btnSuaSP.Enabled = true;
                btnXoaSP.Enabled = true;
                btnThemSP.Enabled = false;

                txtIdSP.Text = dgvProduct.CurrentRow.Cells[0].Value.ToString();
                txtNameProduct.Text = dgvProduct.CurrentRow.Cells[1].Value.ToString();
                txtPrice.Text = dgvProduct.CurrentRow.Cells[2].Value.ToString();
                txtQuantity.Text = dgvProduct.CurrentRow.Cells[6].Value.ToString();
                //Tạo if để khi mà click ra ngoài vùng dư liệu không hiển thị trong dataGridview thì sẽ không lỗi
                if (txtIdSP.Text == "")
                {
                    SetValue(true, false);
                }
                else
                {
                    MemoryStream memoryStream = new MemoryStream((byte[])dgvProduct.CurrentRow.Cells[3].Value);
                    picBox.Image = Image.FromStream(memoryStream);
                    cbCateID.SelectedValue = dgvProduct.CurrentRow.Cells[4].Value.ToString();
                    cbSupplierID.SelectedValue = dgvProduct.CurrentRow.Cells[5].Value.ToString();
                }
            }
        }
        private void btnDSXoa_Click(object sender, EventArgs e)
        {
            dgvProduct.DataSource = ProductsDAL.Instance.ListOfProductDel();

            dgvProduct.Columns[0].HeaderText = "Mã hàng";
            dgvProduct.Columns[1].HeaderText = "Tên hàng";
            dgvProduct.Columns[2].HeaderText = "Đơn giá";
            dgvProduct.Columns[3].HeaderText = "Hình ảnh";
            dgvProduct.Columns[4].HeaderText = "Mã danh mục";
            dgvProduct.Columns[5].HeaderText = "Mã nhà cung cấp";
            dgvProduct.Columns[6].HeaderText = "Số lượng tồn";

            foreach (DataGridViewColumn item in dgvProduct.Columns)
                item.DividerWidth = 1;

            DataGridViewImageColumn imgCol = new DataGridViewImageColumn();
            imgCol = (DataGridViewImageColumn)dgvProduct.Columns[3];
            imgCol.ImageLayout = DataGridViewImageCellLayout.Zoom;

            dgvProduct.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvProduct.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvProduct.Columns[0].Visible = false;
            dgvProduct.Columns[4].Visible = false;
            dgvProduct.Columns[5].Visible = false;
        }
        #endregion

        private void btnPhucHoi_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn khôi phục dữ liệu lại không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    int id = Convert.ToInt32(txtPhucHoi.Text);

                    if (txtPhucHoi.Text == "")
                    {
                        MessageBox.Show("Nhập dữ liệu cần khôi phục,không được để trống", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else if (id != ProductsDAL.Instance.GetIdProduct(id))
                    {
                        MessageBox.Show("Mã sản phẩm không tồn tại", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        ProductsDAL.Instance.PhucHoi(id);
                        MessageBox.Show("Phục hồi thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        SetValue(true, false);
                        LoadGridView(frmSaP);
                        txtPhucHoi.Text = "";
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu cần khôi phục thất bại có thể thiếu hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
