﻿namespace ShoeShopManagement.GUI
{
    partial class frmPhieuNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.radChuaThanhToan = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.radDaThanhToan = new Guna.UI2.WinForms.Guna2RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDay = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnChiTietPN = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnResetPN = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnXoaPN = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnSuaPN = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnThemPN = new Guna.UI2.WinForms.Guna2GradientButton();
            this.CheckDateImport = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.cbUserID = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbSupplierID = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtIdPN = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvImportCoupon = new Guna.UI2.WinForms.Guna2DataGridView();
            this.btnListImportCoupon = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txtPhucHoi = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnPhucHoi = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnDSXoa = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvImportCoupon)).BeginInit();
            this.SuspendLayout();
            // 
            // radChuaThanhToan
            // 
            this.radChuaThanhToan.Animated = true;
            this.radChuaThanhToan.AutoSize = true;
            this.radChuaThanhToan.Checked = true;
            this.radChuaThanhToan.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radChuaThanhToan.CheckedState.BorderThickness = 0;
            this.radChuaThanhToan.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radChuaThanhToan.CheckedState.InnerColor = System.Drawing.Color.White;
            this.radChuaThanhToan.CheckedState.InnerOffset = -4;
            this.radChuaThanhToan.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radChuaThanhToan.Location = new System.Drawing.Point(20, 11);
            this.radChuaThanhToan.Name = "radChuaThanhToan";
            this.radChuaThanhToan.Size = new System.Drawing.Size(136, 20);
            this.radChuaThanhToan.TabIndex = 6;
            this.radChuaThanhToan.TabStop = true;
            this.radChuaThanhToan.Text = "Chưa Thanh Toán";
            this.radChuaThanhToan.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.radChuaThanhToan.UncheckedState.BorderThickness = 2;
            this.radChuaThanhToan.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.radChuaThanhToan.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.radChuaThanhToan.UseVisualStyleBackColor = true;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Controls.Add(this.radDaThanhToan);
            this.guna2GroupBox1.Controls.Add(this.radChuaThanhToan);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(227, 164);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(165, 61);
            this.guna2GroupBox1.TabIndex = 68;
            // 
            // radDaThanhToan
            // 
            this.radDaThanhToan.Animated = true;
            this.radDaThanhToan.AutoSize = true;
            this.radDaThanhToan.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radDaThanhToan.CheckedState.BorderThickness = 0;
            this.radDaThanhToan.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radDaThanhToan.CheckedState.InnerColor = System.Drawing.Color.White;
            this.radDaThanhToan.CheckedState.InnerOffset = -4;
            this.radDaThanhToan.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radDaThanhToan.Location = new System.Drawing.Point(20, 11);
            this.radDaThanhToan.Name = "radDaThanhToan";
            this.radDaThanhToan.Size = new System.Drawing.Size(121, 20);
            this.radDaThanhToan.TabIndex = 6;
            this.radDaThanhToan.Text = "Đã Thanh Toán";
            this.radDaThanhToan.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.radDaThanhToan.UncheckedState.BorderThickness = 2;
            this.radDaThanhToan.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.radDaThanhToan.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.radDaThanhToan.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(65, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 19);
            this.label4.TabIndex = 67;
            this.label4.Text = "Trạng thái phiếu :";
            // 
            // txtDay
            // 
            this.txtDay.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(153)))), ((int)(((byte)(149)))));
            this.txtDay.BorderRadius = 6;
            this.txtDay.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDay.DefaultText = "";
            this.txtDay.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDay.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDay.DisabledState.Parent = this.txtDay;
            this.txtDay.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDay.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.txtDay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDay.FocusedState.Parent = this.txtDay;
            this.txtDay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDay.ForeColor = System.Drawing.Color.White;
            this.txtDay.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDay.HoverState.Parent = this.txtDay;
            this.txtDay.Location = new System.Drawing.Point(250, 107);
            this.txtDay.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDay.Name = "txtDay";
            this.txtDay.PasswordChar = '\0';
            this.txtDay.PlaceholderText = "";
            this.txtDay.ReadOnly = true;
            this.txtDay.SelectedText = "";
            this.txtDay.ShadowDecoration.Parent = this.txtDay;
            this.txtDay.Size = new System.Drawing.Size(137, 36);
            this.txtDay.TabIndex = 66;
            // 
            // btnChiTietPN
            // 
            this.btnChiTietPN.BorderRadius = 10;
            this.btnChiTietPN.CheckedState.Parent = this.btnChiTietPN;
            this.btnChiTietPN.CustomImages.Parent = this.btnChiTietPN;
            this.btnChiTietPN.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiTietPN.ForeColor = System.Drawing.Color.White;
            this.btnChiTietPN.HoverState.Parent = this.btnChiTietPN;
            this.btnChiTietPN.Location = new System.Drawing.Point(227, 222);
            this.btnChiTietPN.Name = "btnChiTietPN";
            this.btnChiTietPN.ShadowDecoration.Parent = this.btnChiTietPN;
            this.btnChiTietPN.Size = new System.Drawing.Size(142, 45);
            this.btnChiTietPN.TabIndex = 65;
            this.btnChiTietPN.Text = "Chi Tiết Phiếu Nhập";
            this.btnChiTietPN.Click += new System.EventHandler(this.btnChiTietPN_Click);
            // 
            // btnResetPN
            // 
            this.btnResetPN.BorderRadius = 10;
            this.btnResetPN.CheckedState.Parent = this.btnResetPN;
            this.btnResetPN.CustomImages.Parent = this.btnResetPN;
            this.btnResetPN.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetPN.ForeColor = System.Drawing.Color.White;
            this.btnResetPN.HoverState.Parent = this.btnResetPN;
            this.btnResetPN.Location = new System.Drawing.Point(724, 171);
            this.btnResetPN.Name = "btnResetPN";
            this.btnResetPN.ShadowDecoration.Parent = this.btnResetPN;
            this.btnResetPN.Size = new System.Drawing.Size(142, 45);
            this.btnResetPN.TabIndex = 63;
            this.btnResetPN.Text = "Làm mới";
            this.btnResetPN.Click += new System.EventHandler(this.btnResetPN_Click);
            // 
            // btnXoaPN
            // 
            this.btnXoaPN.BorderRadius = 10;
            this.btnXoaPN.CheckedState.Parent = this.btnXoaPN;
            this.btnXoaPN.CustomImages.Parent = this.btnXoaPN;
            this.btnXoaPN.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPN.ForeColor = System.Drawing.Color.White;
            this.btnXoaPN.HoverState.Parent = this.btnXoaPN;
            this.btnXoaPN.Location = new System.Drawing.Point(724, 120);
            this.btnXoaPN.Name = "btnXoaPN";
            this.btnXoaPN.ShadowDecoration.Parent = this.btnXoaPN;
            this.btnXoaPN.Size = new System.Drawing.Size(142, 45);
            this.btnXoaPN.TabIndex = 62;
            this.btnXoaPN.Text = "Xóa";
            this.btnXoaPN.Click += new System.EventHandler(this.btnXoaPN_Click);
            // 
            // btnSuaPN
            // 
            this.btnSuaPN.BorderRadius = 10;
            this.btnSuaPN.CheckedState.Parent = this.btnSuaPN;
            this.btnSuaPN.CustomImages.Parent = this.btnSuaPN;
            this.btnSuaPN.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaPN.ForeColor = System.Drawing.Color.White;
            this.btnSuaPN.HoverState.Parent = this.btnSuaPN;
            this.btnSuaPN.Location = new System.Drawing.Point(724, 69);
            this.btnSuaPN.Name = "btnSuaPN";
            this.btnSuaPN.ShadowDecoration.Parent = this.btnSuaPN;
            this.btnSuaPN.Size = new System.Drawing.Size(142, 45);
            this.btnSuaPN.TabIndex = 61;
            this.btnSuaPN.Text = "Sửa";
            this.btnSuaPN.Click += new System.EventHandler(this.btnSuaPN_Click);
            // 
            // btnThemPN
            // 
            this.btnThemPN.BorderRadius = 10;
            this.btnThemPN.CheckedState.Parent = this.btnThemPN;
            this.btnThemPN.CustomImages.Parent = this.btnThemPN;
            this.btnThemPN.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemPN.ForeColor = System.Drawing.Color.White;
            this.btnThemPN.HoverState.Parent = this.btnThemPN;
            this.btnThemPN.Location = new System.Drawing.Point(724, 18);
            this.btnThemPN.Name = "btnThemPN";
            this.btnThemPN.ShadowDecoration.Parent = this.btnThemPN;
            this.btnThemPN.Size = new System.Drawing.Size(142, 45);
            this.btnThemPN.TabIndex = 60;
            this.btnThemPN.Text = "Thêm";
            this.btnThemPN.Click += new System.EventHandler(this.btnThemPN_Click);
            // 
            // CheckDateImport
            // 
            this.CheckDateImport.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.CheckDateImport.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.CheckDateImport.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.CheckDateImport.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.CheckDateImport.Location = new System.Drawing.Point(397, 115);
            this.CheckDateImport.Name = "CheckDateImport";
            this.CheckDateImport.Size = new System.Drawing.Size(137, 23);
            this.CheckDateImport.TabIndex = 59;
            this.CheckDateImport.ValueChanged += new System.EventHandler(this.CheckDateImport_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(474, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 19);
            this.label3.TabIndex = 58;
            this.label3.Text = "Người Nhập :";
            // 
            // cbUserID
            // 
            this.cbUserID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.cbUserID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(153)))), ((int)(((byte)(149)))));
            this.cbUserID.BorderRadius = 6;
            this.cbUserID.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbUserID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbUserID.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.cbUserID.FocusedColor = System.Drawing.Color.Empty;
            this.cbUserID.FocusedState.Parent = this.cbUserID;
            this.cbUserID.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbUserID.ForeColor = System.Drawing.Color.White;
            this.cbUserID.FormattingEnabled = true;
            this.cbUserID.HoverState.Parent = this.cbUserID;
            this.cbUserID.ItemHeight = 30;
            this.cbUserID.ItemsAppearance.Parent = this.cbUserID;
            this.cbUserID.Location = new System.Drawing.Point(478, 51);
            this.cbUserID.Name = "cbUserID";
            this.cbUserID.ShadowDecoration.Parent = this.cbUserID;
            this.cbUserID.Size = new System.Drawing.Size(160, 36);
            this.cbUserID.TabIndex = 57;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(232, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 19);
            this.label8.TabIndex = 56;
            this.label8.Text = "Nhà Cung Cấp :";
            // 
            // cbSupplierID
            // 
            this.cbSupplierID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.cbSupplierID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(153)))), ((int)(((byte)(149)))));
            this.cbSupplierID.BorderRadius = 6;
            this.cbSupplierID.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbSupplierID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSupplierID.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.cbSupplierID.FocusedColor = System.Drawing.Color.Empty;
            this.cbSupplierID.FocusedState.Parent = this.cbSupplierID;
            this.cbSupplierID.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbSupplierID.ForeColor = System.Drawing.Color.White;
            this.cbSupplierID.FormattingEnabled = true;
            this.cbSupplierID.HoverState.Parent = this.cbSupplierID;
            this.cbSupplierID.ItemHeight = 30;
            this.cbSupplierID.ItemsAppearance.Parent = this.cbSupplierID;
            this.cbSupplierID.Location = new System.Drawing.Point(236, 51);
            this.cbSupplierID.Name = "cbSupplierID";
            this.cbSupplierID.ShadowDecoration.Parent = this.cbSupplierID;
            this.cbSupplierID.Size = new System.Drawing.Size(211, 36);
            this.cbSupplierID.TabIndex = 55;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(65, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 19);
            this.label2.TabIndex = 54;
            this.label2.Text = "Thời gian tạo phiếu :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(65, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 19);
            this.label1.TabIndex = 53;
            this.label1.Text = "Mã Phiếu Nhập :";
            // 
            // txtIdPN
            // 
            this.txtIdPN.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(153)))), ((int)(((byte)(149)))));
            this.txtIdPN.BorderRadius = 6;
            this.txtIdPN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtIdPN.DefaultText = "";
            this.txtIdPN.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtIdPN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtIdPN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtIdPN.DisabledState.Parent = this.txtIdPN;
            this.txtIdPN.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtIdPN.Enabled = false;
            this.txtIdPN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.txtIdPN.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtIdPN.FocusedState.Parent = this.txtIdPN;
            this.txtIdPN.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdPN.ForeColor = System.Drawing.Color.White;
            this.txtIdPN.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtIdPN.HoverState.Parent = this.txtIdPN;
            this.txtIdPN.Location = new System.Drawing.Point(69, 51);
            this.txtIdPN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtIdPN.Name = "txtIdPN";
            this.txtIdPN.PasswordChar = '\0';
            this.txtIdPN.PlaceholderText = "";
            this.txtIdPN.ReadOnly = true;
            this.txtIdPN.SelectedText = "";
            this.txtIdPN.ShadowDecoration.Parent = this.txtIdPN;
            this.txtIdPN.Size = new System.Drawing.Size(134, 36);
            this.txtIdPN.TabIndex = 52;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(65, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(216, 19);
            this.label6.TabIndex = 50;
            this.label6.Text = "DANH SÁCH PHIẾU NHẬP";
            // 
            // dgvImportCoupon
            // 
            this.dgvImportCoupon.AllowUserToAddRows = false;
            this.dgvImportCoupon.AllowUserToDeleteRows = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            this.dgvImportCoupon.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvImportCoupon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvImportCoupon.BackgroundColor = System.Drawing.Color.Silver;
            this.dgvImportCoupon.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvImportCoupon.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvImportCoupon.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvImportCoupon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvImportCoupon.ColumnHeadersHeight = 30;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvImportCoupon.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvImportCoupon.EnableHeadersVisualStyles = false;
            this.dgvImportCoupon.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvImportCoupon.Location = new System.Drawing.Point(68, 349);
            this.dgvImportCoupon.Name = "dgvImportCoupon";
            this.dgvImportCoupon.ReadOnly = true;
            this.dgvImportCoupon.RowHeadersVisible = false;
            this.dgvImportCoupon.RowTemplate.Height = 25;
            this.dgvImportCoupon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvImportCoupon.Size = new System.Drawing.Size(798, 233);
            this.dgvImportCoupon.TabIndex = 49;
            this.dgvImportCoupon.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.dgvImportCoupon.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvImportCoupon.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvImportCoupon.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvImportCoupon.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvImportCoupon.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvImportCoupon.ThemeStyle.BackColor = System.Drawing.Color.Silver;
            this.dgvImportCoupon.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvImportCoupon.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Silver;
            this.dgvImportCoupon.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvImportCoupon.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvImportCoupon.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvImportCoupon.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvImportCoupon.ThemeStyle.HeaderStyle.Height = 30;
            this.dgvImportCoupon.ThemeStyle.ReadOnly = true;
            this.dgvImportCoupon.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvImportCoupon.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvImportCoupon.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvImportCoupon.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvImportCoupon.ThemeStyle.RowsStyle.Height = 25;
            this.dgvImportCoupon.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvImportCoupon.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvImportCoupon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvImportCoupon_CellClick);
            // 
            // btnListImportCoupon
            // 
            this.btnListImportCoupon.BorderRadius = 10;
            this.btnListImportCoupon.CheckedState.Parent = this.btnListImportCoupon;
            this.btnListImportCoupon.CustomImages.Parent = this.btnListImportCoupon;
            this.btnListImportCoupon.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListImportCoupon.ForeColor = System.Drawing.Color.White;
            this.btnListImportCoupon.HoverState.Parent = this.btnListImportCoupon;
            this.btnListImportCoupon.Location = new System.Drawing.Point(69, 222);
            this.btnListImportCoupon.Name = "btnListImportCoupon";
            this.btnListImportCoupon.ShadowDecoration.Parent = this.btnListImportCoupon;
            this.btnListImportCoupon.Size = new System.Drawing.Size(142, 45);
            this.btnListImportCoupon.TabIndex = 69;
            this.btnListImportCoupon.Text = "Chi Tiết Nhập Hàng";
            this.btnListImportCoupon.Click += new System.EventHandler(this.btnListImportCoupon_Click);
            // 
            // txtPhucHoi
            // 
            this.txtPhucHoi.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(153)))), ((int)(((byte)(149)))));
            this.txtPhucHoi.BorderRadius = 6;
            this.txtPhucHoi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPhucHoi.DefaultText = "";
            this.txtPhucHoi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPhucHoi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPhucHoi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPhucHoi.DisabledState.Parent = this.txtPhucHoi;
            this.txtPhucHoi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPhucHoi.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.txtPhucHoi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPhucHoi.FocusedState.Parent = this.txtPhucHoi;
            this.txtPhucHoi.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhucHoi.ForeColor = System.Drawing.Color.White;
            this.txtPhucHoi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPhucHoi.HoverState.Parent = this.txtPhucHoi;
            this.txtPhucHoi.Location = new System.Drawing.Point(637, 293);
            this.txtPhucHoi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPhucHoi.Name = "txtPhucHoi";
            this.txtPhucHoi.PasswordChar = '\0';
            this.txtPhucHoi.PlaceholderText = "Nhập mã pn để khôi phục";
            this.txtPhucHoi.SelectedText = "";
            this.txtPhucHoi.ShadowDecoration.Parent = this.txtPhucHoi;
            this.txtPhucHoi.Size = new System.Drawing.Size(229, 49);
            this.txtPhucHoi.TabIndex = 74;
            // 
            // btnPhucHoi
            // 
            this.btnPhucHoi.BorderRadius = 10;
            this.btnPhucHoi.CheckedState.Parent = this.btnPhucHoi;
            this.btnPhucHoi.CustomImages.Parent = this.btnPhucHoi;
            this.btnPhucHoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhucHoi.ForeColor = System.Drawing.Color.White;
            this.btnPhucHoi.HoverState.Parent = this.btnPhucHoi;
            this.btnPhucHoi.Location = new System.Drawing.Point(487, 296);
            this.btnPhucHoi.Name = "btnPhucHoi";
            this.btnPhucHoi.ShadowDecoration.Parent = this.btnPhucHoi;
            this.btnPhucHoi.Size = new System.Drawing.Size(142, 45);
            this.btnPhucHoi.TabIndex = 73;
            this.btnPhucHoi.Text = "Khôi phục dữ liệu";
            this.btnPhucHoi.Click += new System.EventHandler(this.btnPhucHoi_Click);
            // 
            // btnDSXoa
            // 
            this.btnDSXoa.BorderRadius = 10;
            this.btnDSXoa.CheckedState.Parent = this.btnDSXoa;
            this.btnDSXoa.CustomImages.Parent = this.btnDSXoa;
            this.btnDSXoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSXoa.ForeColor = System.Drawing.Color.White;
            this.btnDSXoa.HoverState.Parent = this.btnDSXoa;
            this.btnDSXoa.Location = new System.Drawing.Point(724, 222);
            this.btnDSXoa.Name = "btnDSXoa";
            this.btnDSXoa.ShadowDecoration.Parent = this.btnDSXoa;
            this.btnDSXoa.Size = new System.Drawing.Size(142, 45);
            this.btnDSXoa.TabIndex = 75;
            this.btnDSXoa.Text = "Danh sách xóa";
            this.btnDSXoa.Click += new System.EventHandler(this.btnDSXoa_Click);
            // 
            // frmPhieuNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(930, 600);
            this.Controls.Add(this.btnDSXoa);
            this.Controls.Add(this.txtPhucHoi);
            this.Controls.Add(this.btnPhucHoi);
            this.Controls.Add(this.btnListImportCoupon);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtDay);
            this.Controls.Add(this.btnChiTietPN);
            this.Controls.Add(this.btnResetPN);
            this.Controls.Add(this.btnXoaPN);
            this.Controls.Add(this.btnSuaPN);
            this.Controls.Add(this.btnThemPN);
            this.Controls.Add(this.CheckDateImport);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbUserID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbSupplierID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtIdPN);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgvImportCoupon);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(930, 600);
            this.MinimumSize = new System.Drawing.Size(930, 600);
            this.Name = "frmPhieuNhap";
            this.Text = "frmPhieuNhap";
            this.Load += new System.EventHandler(this.frmPhieuNhap_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvImportCoupon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2RadioButton radChuaThanhToan;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2RadioButton radDaThanhToan;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtDay;
        private Guna.UI2.WinForms.Guna2GradientButton btnChiTietPN;
        private Guna.UI2.WinForms.Guna2GradientButton btnResetPN;
        private Guna.UI2.WinForms.Guna2GradientButton btnXoaPN;
        private Guna.UI2.WinForms.Guna2GradientButton btnSuaPN;
        private Guna.UI2.WinForms.Guna2GradientButton btnThemPN;
        private System.Windows.Forms.DateTimePicker CheckDateImport;
        private System.Windows.Forms.Label label3;
        public Guna.UI2.WinForms.Guna2ComboBox cbUserID;
        private System.Windows.Forms.Label label8;
        public Guna.UI2.WinForms.Guna2ComboBox cbSupplierID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtIdPN;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2DataGridView dgvImportCoupon;
        private Guna.UI2.WinForms.Guna2GradientButton btnListImportCoupon;
        private Guna.UI2.WinForms.Guna2TextBox txtPhucHoi;
        private Guna.UI2.WinForms.Guna2GradientButton btnPhucHoi;
        private Guna.UI2.WinForms.Guna2GradientButton btnDSXoa;
    }
}