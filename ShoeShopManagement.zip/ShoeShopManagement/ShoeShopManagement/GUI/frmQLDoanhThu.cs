﻿using ShoeShopManagement.DAL;
using ShoeShopManagement.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace ShoeShopManagement.GUI
{
    public partial class frmQLDoanhThu : Form
    {
        frmTrangChu tc;
        public frmQLDoanhThu()
        {
            InitializeComponent();
        }

        public void frmQLDoanhThu_Load(object sender, EventArgs e)
        {
            LoadALL();
        }

        #region Methods
        public void LoadALL()
        {
            LoadpnlAll();
            LoadGetListBill();
        }
        void LoadpnlAll()
        {
            lblDoanhThu.Text = "Tổng doanh thu : " + BillDAL.Instance.GetSumToTalBill() +" VNĐ";
            lblGiayBanRa.Text = "Số lượng giày bán ra : " + BillInfoDAL.Instance.GetTotalShoes();
            lblKhachHang.Text = "Tổng khách hàng : " + CustomersDAL.Instance.GetTotalCustomer();
            lblNCC.Text = "Số lượng hơp tác với nhà cung cấp : " + SupplierDAL.Instance.GetTotalSupplier();
        }
        void LoadGetListBill()
        {
            string format = "MM/dd/yyyy";
            DateTime now = DateTime.Now.AddDays(1);
            string s1 = now.ToString(format);

            dgvThongKe.DataSource = BillDAL.Instance.GetListBill(s1);
        }

        public static DateTime GetFirstDayOfMonth(DateTime dtInput)
        {
            DateTime dtResult = dtInput;
            dtResult = dtResult.AddDays((-dtResult.Day) + 1);
            return dtResult;
        }
        #endregion



        #region Events
        private void btnThongKe_Click(object sender, EventArgs e)
        {
            double TongTienHT = 0;
            string format = "MM/dd/yyyy";

            if (cbDate.SelectedIndex == 0)
            {
                DateTime now = DateTime.Now;
                DateTime tmr = DateTime.Now.AddDays(1);

                string s1 = now.ToString(format);
                string s2 = tmr.ToString(format);


                dgvThongKe.DataSource = BillDAL.Instance.GetTotalDate(s1,s2);

                for (int i = 0; i < dgvThongKe.Rows.Count; i++)
                {
                    TongTienHT += (double.Parse(dgvThongKe.Rows[i].Cells[2].Value.ToString()));
                }

                lblThongKe.Text = "Tổng doanh thu ngày : " + TongTienHT.ToString();
            }
            else if (cbDate.SelectedIndex == 1)
            {

                DateTime td = DateTime.Now;
                DateTime dayXH = DateTime.Now.AddDays(-7);

                string s1 = td.ToString(format);
                string s2 = dayXH.ToString(format);

                dgvThongKe.DataSource = BillDAL.Instance.Get7Date(s1, s2);

                for (int i = 0; i < dgvThongKe.Rows.Count; i++)
                {
                    TongTienHT += (double.Parse(dgvThongKe.Rows[i].Cells[2].Value.ToString()));
                }

                lblThongKe.Text = "Tổng doanh thu 7 ngày qua : " + TongTienHT.ToString();
            }
            else if (cbDate.SelectedIndex == -1)
            {
                MessageBox.Show("Chọn để thống kê", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
            else
            {
                DateTime td = DateTime.Now.AddDays(1);
                DateTime kq = GetFirstDayOfMonth(td);

                string s1 = td.ToString(format);
                string s2 = kq.ToString(format);

                dgvThongKe.DataSource = BillDAL.Instance.GetListBillByDate(s1, s2);

                for (int i = 0; i < dgvThongKe.Rows.Count; i++)
                {
                    TongTienHT += (double.Parse(dgvThongKe.Rows[i].Cells[2].Value.ToString()));
                }

                lblThongKe.Text = "Tổng doanh thu tháng này : " + TongTienHT.ToString();
            }
        }
        #endregion
    }
}
