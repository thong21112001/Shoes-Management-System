﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmDanhMucSP : Form
    {
        frmDanhMucSP frmDM;

        public frmDanhMucSP()
        {
            InitializeComponent();
            LoadALL();
        }
        public void frmDanhMucSP_Load(object sender, EventArgs e)
        {
            LoadALL();
        }

        #region Methods
        //Hàm LoadALL
        void LoadALL()
        {
            LoadGridView();
            SetValue(true, false);
        }

        //Hàm Reset trường data
        public void ResetTextALL(frmDanhMucSP frmDM)
        {
            txtId.Text = "";
            txtNameCate.Text = "";
        }

        //Hàm set value
        private void SetValue(bool param, bool isLoad)
        {
            txtId.Text = null;
            txtNameCate.Text = null;
            txtSearch.Text = null;

            btnThem.Enabled = param;
            if (isLoad)
            {
                btnSua.Enabled = false;
                btnXoa.Enabled = false;
            }
            else
            {
                btnSua.Enabled = !param;
                btnXoa.Enabled = !param;
            }
        }

        //Hàm load lên data GirdView
        public void LoadGridView()
        {
            dgvDanhMuc.DataSource = CategoryDAL.Instance.ListOfCategory();

            dgvDanhMuc.Columns[0].HeaderText = "Mã danh mục";
            dgvDanhMuc.Columns[1].HeaderText = "Tên danh mục";

            foreach (DataGridViewColumn item in dgvDanhMuc.Columns)
                item.DividerWidth = 1;
            dgvDanhMuc.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvDanhMuc.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvDanhMuc.Columns[0].Visible = false;
        }
        #endregion


        #region Events
        private void btnThem_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thêm danh mục này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtNameCate.Text == "")
                    {
                        MessageBox.Show("Thêm danh mục thất bại có thể thiếu các ô bị trống !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string nameCate = txtNameCate.Text;
                        int statusCate = 1;

                        CategoryDAL.Instance.InsertCate(nameCate,statusCate);
                        MessageBox.Show("Thêm danh mục thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmDM);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm danh mục thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn cập nhập danh mục này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtId.Text == "" || txtNameCate.Text == "")
                    {
                        MessageBox.Show("Cập nhập danh mục thất bại có thể thiếu các ô bị trống !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtId.Text);
                        string nameCate = txtNameCate.Text;

                        CategoryDAL.Instance.UpdateCate(nameCate, id);
                        MessageBox.Show("Sửa danh mục thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Sửa danh mục thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn xóa danh mục này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtId.Text == "")
                    {
                        MessageBox.Show("Xóa danh mục thất bại có thể thiếu id danh mục \n Bấm vào bảng phía dưới để lấy id danh mục!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtId.Text);

                        CategoryDAL.Instance.DelCate(id);
                        MessageBox.Show("Xóa danh mục thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmDM);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa danh mục thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        public void btnReset_Click(object sender, EventArgs e)
        {
            SetValue(true, false);
            LoadGridView();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string name;
            name = txtSearch.Text.Trim();
            if (name == "")
            {
                frmDanhMucSP_Load(sender, e);
                txtSearch.Focus();
            }
            else
            {
                DataTable data = CategoryDAL.Instance.SearchCate(name);
                dgvDanhMuc.DataSource = data;
            }
        }

        private void dgvDanhMuc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvDanhMuc.Rows.Count > 0)
            {
                btnSua.Enabled = true;
                btnXoa.Enabled = true;
                btnThem.Enabled = false;

                txtId.Text = dgvDanhMuc.CurrentRow.Cells[0].Value.ToString();
                txtNameCate.Text = dgvDanhMuc.CurrentRow.Cells[1].Value.ToString();
            }
        }

        private void btnDSXoa_Click(object sender, EventArgs e)
        {
            dgvDanhMuc.DataSource = CategoryDAL.Instance.ListOfCategoryDel();

            dgvDanhMuc.Columns[0].HeaderText = "Mã danh mục";
            dgvDanhMuc.Columns[1].HeaderText = "Tên danh mục";

            foreach (DataGridViewColumn item in dgvDanhMuc.Columns)
                item.DividerWidth = 1;
            dgvDanhMuc.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvDanhMuc.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvDanhMuc.Columns[0].Visible = false;
        }

        private void btnPhucHoi_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn khôi phục dữ liệu lại không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    int id = Convert.ToInt32(txtPhucHoi.Text);

                    if (txtPhucHoi.Text == "")
                    {
                        MessageBox.Show("Nhập dữ liệu cần khôi phục,không được để trống", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else if (id != CategoryDAL.Instance.GetIDCate(id))
                    {
                        MessageBox.Show("Mã danh mục không tồn tại", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        CategoryDAL.Instance.PhucHoi(id);
                        MessageBox.Show("Phục hồi thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        SetValue(true, false);
                        LoadGridView();
                        txtPhucHoi.Text = "";
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu cần khôi phục thất bại có thể thiếu hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }
        #endregion
    }
}
