﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmQLTaiKhoan : Form
    {
        private int role;

        public frmQLTaiKhoan()
        {
            InitializeComponent();
            LoadALL();
        }

        public void frmQLTaiKhoan_Load(object sender, EventArgs e)
        {
            LoadALL();
        }

        #region Methods
        //Hàm LoadALL
        void LoadALL()
        {
            LoadGridView();
            SetValue(true, false);
        }

        //Hàm Reset trường data
        public void ResetTextALL()
        {
            txtIdTK.Text = null;
            txtNameTK.Text = null;
            txtPassTK.Text = null;
            txtDisplayTK.Text = null;
            txtEmail.Text = null;
        }

        //Hàm set value
        private void SetValue(bool param, bool isLoad)
        {
            txtIdTK.Text = null;
            txtNameTK.Text = null;
            txtPassTK.Text = null;
            txtDisplayTK.Text = null;
            txtEmail.Text = null;
            txtSearch.Text = null;

            btnThemTK.Enabled = param;

            radStaff.Enabled = param;
            radAdmin.Enabled = param;

            if (isLoad)
            {
                btnSuaTK.Enabled = false;
                btnXoaTK.Enabled = false;
            }
            else
            {
                btnSuaTK.Enabled = !param;
                btnXoaTK.Enabled = !param;
            }
            radStaff.Checked = true;

        }

        //Hàm load lên data GirdView
        public void LoadGridView()
        {
            dgvEmployee.DataSource = AccountDAL.Instance.GetAcc();

            dgvEmployee.Columns[0].HeaderText = "Mã nhân viên";
            dgvEmployee.Columns[1].HeaderText = "Tên đăng nhập";
            dgvEmployee.Columns[2].HeaderText = "Password";
            dgvEmployee.Columns[3].HeaderText = "Vai trò";
            dgvEmployee.Columns[4].HeaderText = "Tên hiển thị";
            dgvEmployee.Columns[5].HeaderText = "Email";

            foreach (DataGridViewColumn item in dgvEmployee.Columns)
            {
                item.DividerWidth = 1;
            }

            dgvEmployee.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvEmployee.Columns[0].Visible = false;
            dgvEmployee.Columns[3].Visible = false;
        }
        #endregion




        #region Events
        private void btnThemTK_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thêm tài khoản này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtNameTK.Text == "" || txtDisplayTK.Text == "" || txtPassTK.Text == "" || txtEmail.Text == "")
                        MessageBox.Show("Không bỏ trống các trường !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else
                    {
                        if (radAdmin.Checked == true)
                        {
                            role = Convert.ToInt32(radAdmin.Checked);
                        }
                        else
                        {
                            role = 0;
                        }
                        string nameTK = txtNameTK.Text;
                        string DisplayN = txtDisplayTK.Text;
                        string PassW = txtPassTK.Text;
                        string EmailU = txtEmail.Text;
                        int statusTK = 1;

                        AccountDAL.Instance.InsertUser(nameTK, PassW, role, DisplayN, EmailU, statusTK);
                        MessageBox.Show("Thêm tài khoản thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL();
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm tài khoản thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnSuaTK_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn cập nhập tài khoản này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdTK.Text == "" || txtNameTK.Text == "" || txtDisplayTK.Text == "" || txtPassTK.Text == "" || txtEmail.Text == "")
                    {
                        MessageBox.Show("Sửa tài khoản thất bại có thể thiếu các ô bị trống hoặc định dạng sai \n Bấm bảng bên dưới để lấy dữ liệu!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        if (radAdmin.Checked == true)
                        {
                            role = Convert.ToInt32(radAdmin.Checked);
                        }
                        else
                        {
                            role = 0;
                        }

                        int id = Convert.ToInt32(txtIdTK.Text);
                        string nameTK = txtNameTK.Text;
                        string DisplayN = txtDisplayTK.Text;
                        string PassW = txtPassTK.Text;
                        string EmailU = txtEmail.Text;

                        AccountDAL.Instance.UpdateUser(id, nameTK, PassW, role, DisplayN, EmailU);
                        MessageBox.Show("Sửa tài khoản thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL();
                        frmTrangChu tc = new frmTrangChu();
                        tc.frmTrangChu_Load(sender, e);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Sửa tài khoản thất bại có thể thiếu các ô bị trống hoặc định dạng sai \n Bấm bảng bên dưới để lấy dữ liệu!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnXoaTK_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn xóa tài khoản này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdTK.Text == "")
                    {
                        MessageBox.Show("Xóa tài khoản thất bại có thể thiếu id tài khoản \n Bấm vào bảng phía dưới để lấy id tài khoản!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtIdTK.Text);

                        AccountDAL.Instance.DelUser(id);
                        MessageBox.Show("Xóa tài khoản thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL();
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa tài khoản thất bại có thể thiếu id tài khoản hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnResetTK_Click(object sender, EventArgs e)
        {
            SetValue(true, false);
            LoadGridView();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string name;
            name = txtSearch.Text.Trim();
            if (name == "")
            {
                frmQLTaiKhoan_Load(sender, e);
                txtSearch.Focus();
            }
            else
            {
                DataTable data = AccountDAL.Instance.SearchAcc(name);
                dgvEmployee.DataSource = data;
            }
        }

        private void dgvEmployee_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvEmployee.Rows.Count > 0)
            {
                btnSuaTK.Enabled = true;
                btnXoaTK.Enabled = true;
                btnThemTK.Enabled = false;

                radStaff.Enabled = true;
                radAdmin.Enabled = true;

                txtIdTK.Text = dgvEmployee.CurrentRow.Cells[0].Value.ToString();
                txtNameTK.Text = dgvEmployee.CurrentRow.Cells[1].Value.ToString();
                txtPassTK.Text = dgvEmployee.CurrentRow.Cells[2].Value.ToString();
                txtDisplayTK.Text = dgvEmployee.CurrentRow.Cells[4].Value.ToString();
                txtEmail.Text = dgvEmployee.CurrentRow.Cells[5].Value.ToString();

                string Vt;
                Vt = dgvEmployee.CurrentRow.Cells[3].Value.ToString();

                if (Vt == "1")
                {
                    radAdmin.Checked = true;
                }
                else
                {
                    radStaff.Checked = true;
                }
                if (txtIdTK.Text == "")
                {
                    ResetTextALL();
                }
            }
        }
        private void btnPhucHoi_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn khôi phục dữ liệu lại không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtPhucHoi.Text == "")
                    {
                        MessageBox.Show("Nhập dữ liệu cần khôi phục,không được để trống", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else if(txtPhucHoi.Text != AccountDAL.Instance.GetEmail(txtPhucHoi.Text))
                    {
                        MessageBox.Show("Email không tồn tại", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string ph = txtPhucHoi.Text;
                        AccountDAL.Instance.PhucHoi(ph);
                        MessageBox.Show("Phục hồi thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        SetValue(true, false);
                        LoadGridView();
                        txtPhucHoi.Text = "";
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu cần khôi phục thất bại có thể thiếu hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }
        #endregion

        private void btnDSXoa_Click(object sender, EventArgs e)
        {
            dgvEmployee.DataSource = AccountDAL.Instance.GetAccDel();

            dgvEmployee.Columns[0].HeaderText = "Mã nhân viên";
            dgvEmployee.Columns[1].HeaderText = "Tên đăng nhập";
            dgvEmployee.Columns[2].HeaderText = "Password";
            dgvEmployee.Columns[3].HeaderText = "Vai trò";
            dgvEmployee.Columns[4].HeaderText = "Tên hiển thị";
            dgvEmployee.Columns[5].HeaderText = "Email";

            foreach (DataGridViewColumn item in dgvEmployee.Columns)
            {
                item.DividerWidth = 1;
            }

            dgvEmployee.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvEmployee.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvEmployee.Columns[0].Visible = false;
            dgvEmployee.Columns[3].Visible = false;
        }
    }
}
