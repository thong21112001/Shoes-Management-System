﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmQLNhaCC : Form
    {
        frmQLNhaCC frmQLNCC;

        public frmQLNhaCC()
        {
            InitializeComponent();
            LoadALL();
        }
        public void frmQLNhaCC_Load(object sender, EventArgs e)
        {
            LoadALL();
        }

        #region Methods
        //Hàm LoadALL
        void LoadALL()
        {
            LoadGridView();
            SetValue(true, false);
        }
        //Hàm Reset trường data
        public void ResetTextALL(frmQLNhaCC frmQLNCC)
        {
            txtIdNCC.Text = null;
            txtNameNCC.Text = null;
            txtSĐT.Text = null;
            txtDiaChi.Text = null;
            txtEmail.Text = null;
        }
        //Hàm set value
        private void SetValue(bool param, bool isLoad)
        {
            txtIdNCC.Text = null;
            txtNameNCC.Text = null;
            txtSĐT.Text = null;
            txtDiaChi.Text = null;
            txtEmail.Text = null;
            txtSearch.Text = null;

            btnThemNCC.Enabled = param;

            if (isLoad)
            {
                btnSuaNCC.Enabled = false;
                btnXoaNCC.Enabled = false;
            }
            else
            {
                btnSuaNCC.Enabled = !param;
                btnXoaNCC.Enabled = !param;
            }
        }
        //Hàm load lên data GirdView
        private void LoadGridView()
        {
            dgvSupplier.DataSource = SupplierDAL.Instance.GetSupplier();

            dgvSupplier.Columns[0].HeaderText = "Mã nhà cung cấp";
            dgvSupplier.Columns[1].HeaderText = "Tên nhà cung cấp";
            dgvSupplier.Columns[2].HeaderText = "Địa chỉ";
            dgvSupplier.Columns[3].HeaderText = "Số điện thoại";
            dgvSupplier.Columns[4].HeaderText = "Email";

            foreach (DataGridViewColumn item in dgvSupplier.Columns)
            {
                item.DividerWidth = 1;
            }

            dgvSupplier.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvSupplier.Columns[0].Visible = false;
        }
        #endregion


        #region Events
        private void btnThemNCC_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thêm nhà cung cấp này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtNameNCC.Text == "" || txtSĐT.Text == "" || txtDiaChi.Text == "" || txtEmail.Text == "")
                        MessageBox.Show("Không bỏ trống các trường !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    else
                    {
                        string nameNcc = txtNameNCC.Text;
                        string sdt = txtSĐT.Text;
                        string diachi = txtDiaChi.Text;
                        string EmailU = txtEmail.Text;
                        int statusNCC = 1;

                        SupplierDAL.Instance.InsertSupplier(nameNcc, diachi, sdt, EmailU, statusNCC);
                        MessageBox.Show("Thêm nhà cung cấp thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmQLNCC);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm nhà cung cấp thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnSuaNCC_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn cập nhập nhà cung cấp này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdNCC.Text == "" || txtNameNCC.Text == "" || txtSĐT.Text == "" || txtDiaChi.Text == "" || txtEmail.Text == "")
                    {
                        MessageBox.Show("Sửa nhà cung cấp thất bại có thể thiếu các ô bị trống hoặc định dạng sai \n Bấm bảng bên dưới để lấy dữ liệu!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtIdNCC.Text);
                        string nameNcc = txtNameNCC.Text;
                        string sdt = txtSĐT.Text;
                        string diachi = txtDiaChi.Text;
                        string EmailU = txtEmail.Text;

                        SupplierDAL.Instance.UpdateSupplier(id, nameNcc, diachi, sdt, EmailU);
                        MessageBox.Show("Sửa nhà cung cấp thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmQLNCC);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Sửa nhà cung cấp thất bại có thể thiếu các ô bị trống hoặc định dạng sai \n Bấm bảng bên dưới để lấy dữ liệu!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnXoaNCC_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn xóa nhà cung cấp này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdNCC.Text == "")
                    {
                        MessageBox.Show("Xóa nhà cung cấp thất bại có thể thiếu id tài khoản \n Bấm vào bảng phía dưới để lấy id tài khoản!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtIdNCC.Text);

                        SupplierDAL.Instance.DelSupplier(id);
                        MessageBox.Show("Xóa nhà cung cấp thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        ResetTextALL(frmQLNCC);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa nhà cung cấp thất bại có thể thiếu id tài khoản hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnResetNCC_Click(object sender, EventArgs e)
        {
            SetValue(true, false);
            LoadGridView();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sdt;
            sdt = txtSearch.Text.Trim();
            if (sdt == "")
            {
                frmQLNhaCC_Load(sender, e);
                txtSearch.Focus();
            }
            else
            {
                DataTable data = SupplierDAL.Instance.SearchSupplier(sdt);
                dgvSupplier.DataSource = data;
            }
        }

        private void dgvSupplier_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvSupplier.Rows.Count > 0)
            {
                btnSuaNCC.Enabled = true;
                btnXoaNCC.Enabled = true;
                btnThemNCC.Enabled = false;

                txtIdNCC.Text = dgvSupplier.CurrentRow.Cells[0].Value.ToString();
                txtNameNCC.Text = dgvSupplier.CurrentRow.Cells[1].Value.ToString();
                txtSĐT.Text = dgvSupplier.CurrentRow.Cells[3].Value.ToString();
                txtDiaChi.Text = dgvSupplier.CurrentRow.Cells[2].Value.ToString();
                txtEmail.Text = dgvSupplier.CurrentRow.Cells[4].Value.ToString();
            }
        }

        #endregion

        private void btnDSXoa_Click(object sender, EventArgs e)
        {
            dgvSupplier.DataSource = SupplierDAL.Instance.GetSupplierDel();

            dgvSupplier.Columns[0].HeaderText = "Mã nhà cung cấp";
            dgvSupplier.Columns[1].HeaderText = "Tên nhà cung cấp";
            dgvSupplier.Columns[2].HeaderText = "Địa chỉ";
            dgvSupplier.Columns[3].HeaderText = "Số điện thoại";
            dgvSupplier.Columns[4].HeaderText = "Email";

            foreach (DataGridViewColumn item in dgvSupplier.Columns)
            {
                item.DividerWidth = 1;
            }

            dgvSupplier.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;
            dgvSupplier.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopCenter;

            dgvSupplier.Columns[0].Visible = false;
        }

        private void btnPhucHoi_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn khôi phục dữ liệu lại không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtPhucHoi.Text == "")
                    {
                        MessageBox.Show("Nhập dữ liệu cần khôi phục,không được để trống", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else if (txtPhucHoi.Text != SupplierDAL.Instance.GetSDT(txtPhucHoi.Text))
                    {
                        MessageBox.Show("SĐT không tồn tại", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string ph = txtPhucHoi.Text;
                        SupplierDAL.Instance.PhucHoi(ph);
                        MessageBox.Show("Phục hồi thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        SetValue(true, false);
                        txtPhucHoi.Text = "";
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu cần khôi phục thất bại có thể thiếu hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
