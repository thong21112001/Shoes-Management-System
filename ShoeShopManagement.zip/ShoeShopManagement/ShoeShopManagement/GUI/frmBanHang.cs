﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using ShoeShopManagement.DAL;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Reflection;

namespace ShoeShopManagement.GUI
{
    public partial class frmBanHang : Form
    {
        private string[] listCustomerIdName, listProductNameQuantity;
        private DateTime dateTime = new DateTime();
        private string productName, str;
        private int IdUser;
        private char separator = '|';
        private string[] strlist;

        public frmBanHang(int idUser)
        {
            InitializeComponent();
            this.IdUser = idUser;
        }

        public void frmBanHang_Load(object sender, EventArgs e)
        {
            LoadALL();
        }

        #region Methods
        public void LoadALL()
        {
            LoadData();
            listCustomerIdName = CustomersDAL.Instance.ListCustomerIdName();
            cboCustomerIdName.Items.Clear();
            foreach (string item in listCustomerIdName)
            {
                cboCustomerIdName.Items.Add(item);
            }
        }

        public void LoadData()
        {
            dateTime = DateTime.Now;
            txtDateTime.Text = dateTime.ToString();

            listProductNameQuantity = ProductsDAL.Instance.ListProductNameQuantity();
            cboProductNameQuantity.Items.Clear();
            foreach (string item in listProductNameQuantity)
            {
                cboProductNameQuantity.Items.Add(item);
            }

            txtEmployeeIdName.Text = AccountDAL.Instance.GetEmployeeIdName(IdUser);

            lblMaSP.Visible = false;
            txtMaSP.Visible = false;
            btnUpdate.Enabled = false;
            btnInsert.Enabled = true;
            btnDelete.Enabled = true;
            cboProductNameQuantity.Enabled = true;
        }

        public void LoadGridView()
        {
            gvBillInfo.Columns[0].HeaderText = "Mã SP";
            gvBillInfo.Columns[1].HeaderText = "Tên SP";
            gvBillInfo.Columns[2].HeaderText = "Số lượng";
            gvBillInfo.Columns[3].HeaderText = "Thành tiền";
            foreach (DataGridViewColumn item in gvBillInfo.Columns)
            {
                item.DividerWidth = 1;
            }
            gvBillInfo.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvBillInfo.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvBillInfo.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
        #endregion




        #region Events
        private void btnInsert_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thêm sản phẩm này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (cboProductNameQuantity.Text == "" || cboCustomerIdName.Text == "")
                    {
                        MessageBox.Show("Vui lòng chọn dữ liệu !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        str = cboProductNameQuantity.SelectedItem.ToString();
                        strlist = str.Split(separator);
                        productName = strlist[0].Trim();

                        if (txtQuantity.Text != "" && cboCustomerIdName.SelectedIndex != -1 && cboProductNameQuantity.SelectedIndex != -1)
                        {
                            string idSP = ProductsDAL.Instance.GetIdSP(productName).ToString();
                            int idSp = ProductsDAL.Instance.GetIdSP(productName);
                            int soluongTon = ProductsDAL.Instance.GetQuanTitySP(idSp);
                            int soluong = int.Parse(txtQuantity.Text);
                            double thanhtien = double.Parse(txtUnitPrice.Text);

                            if (soluong > 0 && soluong <= soluongTon)
                            {
                                DataGridViewRow newRow = new DataGridViewRow();
                                newRow.CreateCells(gvBillInfo);
                                newRow.Cells[0].Value = idSp;
                                newRow.Cells[1].Value = productName;
                                newRow.Cells[2].Value = txtQuantity.Text;
                                newRow.Cells[3].Value = txtUnitPrice.Text;
                                gvBillInfo.Rows.Add(newRow);

                                MessageBox.Show("Thêm sản phẩm thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                                txtTotalPrice.Text = null;
                                txtQuantity.Text = null;
                            }
                            else
                            {
                                MessageBox.Show("Số lượng nhập vượt quá tồn kho sp hoặc không đúng !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Nhập vào số lượng !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                        }
                    }    
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm sản phẩm thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtMaSP.Text != "")
            {
                try
                {
                    int MaSP = Convert.ToInt32(txtMaSP.Text);
                    int rowIndex = -1;

                    gvBillInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    try
                    {
                        foreach (DataGridViewRow row in gvBillInfo.Rows)
                        {
                            if (Convert.ToInt32(row.Cells[0].Value.ToString()) == MaSP)
                            {
                                rowIndex = row.Index;
                                gvBillInfo.CurrentCell = gvBillInfo.Rows[rowIndex].Cells[0];
                                gvBillInfo.Rows[gvBillInfo.CurrentCell.RowIndex].Selected = true;
                                gvBillInfo.CurrentRow.Cells[2].Value = txtQuantity.Text;
                                gvBillInfo.CurrentRow.Cells[3].Value = txtUnitPrice.Text;

                                break;
                            }
                        }
                        MessageBox.Show("Sửa số lượng thành công", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadData();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Lỗi không thể sửa được !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Cần có mã sản phẩm !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewCell oneCell in gvBillInfo.SelectedCells)
            {
                if (oneCell.Selected)
                    gvBillInfo.Rows.RemoveAt(oneCell.RowIndex);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtQuantity.Text = null;
            txtUnitPrice.Text = null;
            txtTotalPrice.Text = null;
            LoadData();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (this.gvBillInfo.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Không có sản phẩm trong phiếu nhập !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
            else
            {
                DialogResult dialog;
                dialog = MessageBox.Show("Bạn có muốn thanh toán đơn hàng này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dialog == DialogResult.Yes)
                {
                    try
                    {
                        int status = 1;
                        float TongTienHT = 0;
                        DateTime getdateN = Convert.ToDateTime(txtDateTime.Text.ToString());

                        str = txtEmployeeIdName.Text;
                        strlist = str.Split(separator);
                        string employeeId = strlist[0].Trim();

                        str = cboCustomerIdName.SelectedItem.ToString();
                        strlist = str.Split(separator);
                        string customerId = strlist[0].Trim();

                        for (int i = 0; i < gvBillInfo.Rows.Count; i++)
                        {
                            TongTienHT += (float.Parse(gvBillInfo.Rows[i].Cells[2].Value.ToString()) * float.Parse(gvBillInfo.Rows[i].Cells[3].Value.ToString()));
                        }

                        BillDAL.Instance.InsertBill(Convert.ToInt32(employeeId), Convert.ToInt32(customerId), getdateN, TongTienHT, status);

                        foreach (DataGridViewRow dr in gvBillInfo.Rows)
                        {
                            int idSPHT = Convert.ToInt32(dr.Cells[0].Value.ToString());
                            int soluong = Convert.ToInt32(dr.Cells[2].Value.ToString());
                            float dongia = float.Parse(dr.Cells[3].Value.ToString());

                            BillInfoDAL.Instance.InsertBillInfo(BillDAL.Instance.GetMaxIdBill(), idSPHT, soluong, dongia, status);
                        }
                        MessageBox.Show("Hóa đơn thanh toán thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadData();
                        gvBillInfo.Rows.Clear();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Thanh toán hóa đơn thất bại !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void gvBillInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gvBillInfo.Rows.Count > 0)
            {
                try
                {
                    btnUpdate.Enabled = true;
                    lblMaSP.Visible = true;
                    txtMaSP.Visible = true;
                    string idMaSP = gvBillInfo.CurrentRow.Cells[0].Value.ToString();
                    string txt = gvBillInfo.CurrentRow.Cells[1].Value.ToString();

                    txtQuantity.Text = gvBillInfo.CurrentRow.Cells[2].Value.ToString();
                    txtUnitPrice.Text = gvBillInfo.CurrentRow.Cells[3].Value.ToString();
                    txtMaSP.Text = gvBillInfo.CurrentRow.Cells[0].Value.ToString();

                    btnInsert.Enabled = false;
                    cboProductNameQuantity.Enabled = false;
                    MessageBox.Show(string.Format("Bạn đã chọn {0} này \n Với mã sản phẩm đã chọn {1}", txt, idMaSP), "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                }
                catch (Exception)
                {
                    MessageBox.Show("Chọn tên sản phẩm cần thay đổi và thử lại !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                }
            }
        }

        private void cboProductNameQuantity_SelectedIndexChanged(object sender, EventArgs e)
        {
            string str = cboProductNameQuantity.SelectedItem.ToString();
            char separator = '|';
            String[] strlist = str.Split(separator);
            productName = strlist[0].Trim();
            txtUnitPrice.Text = ProductsDAL.Instance.GetUnitPrice(productName).ToString();
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int soluong = Convert.ToInt32(txtQuantity.Text.ToString());
                int tien = Convert.ToInt32(txtUnitPrice.Text.ToString());

                txtTotalPrice.Text = (soluong * tien).ToString();
            }
            catch (Exception)
            {
                txtTotalPrice.Text = null;
            }
            
        }
        #endregion
    }
}
