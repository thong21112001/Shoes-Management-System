﻿using ShoeShopManagement.DAL;
using ShoeShopManagement.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmHoaDon : Form
    {
        private int IdUser;

        public frmHoaDon(int idUser)
        {
            InitializeComponent();
            this.IdUser = idUser;
        }

        public void frmHoaDon_Load(object sender, EventArgs e)
        {
            LoadGridView();
            LoadBtn();
        }

        #region Methods
        public void LoadBtn()
        {
            if (AccountDAL.Instance.GetStatusUserByTypeAccHoaDon(IdUser) == 1)
            {
                btnXoa.Visible = true;
            }
            else
            {
                btnXoa.Visible = false;
            }
        }

        private void LoadGridView()
        {
            gvBill.DataSource = BillDAL.Instance.GetBill();

            gvBill.Columns[0].HeaderText = "Mã HD";
            gvBill.Columns[1].HeaderText = "Tên KH";
            gvBill.Columns[2].HeaderText = "Thời gian";
            gvBill.Columns[3].HeaderText = "Tổng tiền";
            foreach (DataGridViewColumn item in gvBill.Columns)
            {
                item.DividerWidth = 1;
            }
            gvBill.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvBill.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvBill.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
        #endregion

        #region Events
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string name = txtSearch.Text.Trim();
            if (name == "")
            {
                frmHoaDon_Load(sender, e);
                txtSearch.Focus();
            }
            else
            {
                DataTable data = BillDAL.Instance.SearchCustomerInBill(txtSearch.Text);
                gvBill.DataSource = data;
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn xóa hóa đơn này không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    if (txtIdPN.Text == "")
                    {
                        MessageBox.Show("Xóa hóa đơn thất bại có thể thiếu id sản phẩm \n Bấm vào bảng phía dưới để lấy id sản phẩm!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtIdPN.Text);

                        BillDAL.Instance.DelBill(id);
                        MessageBox.Show("Xóa hóa đơn thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        LoadGridView();
                        txtIdPN.Text = null;
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa hóa đơn thất bại có thể thiếu các ô bị trống hoặc định dạng sai!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSearch.Text = null;
            txtIdPN.Text = null;
        }

        private void btnChiTietPN_Click(object sender, EventArgs e)
        {
            if (txtIdPN.Text != "")
            {
                int idPNCT = Convert.ToInt32(txtIdPN.Text);
                frmCTHoaDon i4 = new frmCTHoaDon(idPNCT);
                i4.ShowDialog();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn 1 hóa đơn để xem chi tiết trong bảng bên dưới!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        private void gvBill_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gvBill.Rows.Count > 0)
            {
                txtIdPN.Text = gvBill.CurrentRow.Cells[0].Value.ToString();
            }
        }
        #endregion
    }
}
