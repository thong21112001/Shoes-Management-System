﻿using ShoeShopManagement.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeShopManagement.GUI
{
    public partial class frmCTPhieuNhap : Form
    {
        frmPhieuNhap ic = new frmPhieuNhap();
        frmSanPham frmSP = new frmSanPham();
        int idNhapKho;

        public frmCTPhieuNhap(int idNhapKho)
        {
            InitializeComponent();
            this.idNhapKho = idNhapKho;
            LoadALL();
        }

        private void frmCTPhieuNhap_Load(object sender, EventArgs e)
        {
            lbIdPN.Text = this.idNhapKho.ToString();
            LoadALL();
        }

        #region Methods
        //Hàm LoadALL
        void LoadALL()
        {
            LoadSP();
            ic.LoadGridView(ic);
        }
        //Load dữ liệu lên combo Box cbUserID
        void LoadSP()
        {
            try
            {
                string sql = "Select * from dbo.tblProduct where Status = 1";
                cbProductID.DataSource = DataProvider.Instance.ExQuery(sql);
                cbProductID.DisplayMember = "NameSP";
                cbProductID.ValueMember = "NameSP";
            }
            catch (Exception)
            {
                MessageBox.Show("Load dữ liệu không được", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
        #endregion



        #region Events
        int n = 0;
        private void btnThem_Click(object sender, EventArgs e)
        {
            if (txtQuantity.Text == "")
            {
                MessageBox.Show("Nhập số lượng !!!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
            else
            {
                //Nếu txtQuantityBook.Text > 0 thì tạo row ở dgvBill
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(dgvImcId);
                newRow.Cells[0].Value = n + 1;
                newRow.Cells[1].Value = lbIdPN.Text;
                newRow.Cells[2].Value = cbProductID.Text;
                newRow.Cells[3].Value = txtQuantity.Text;
                dgvImcId.Rows.Add(newRow);
                n++;
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewCell oneCell in dgvImcId.SelectedCells)
            {
                if (oneCell.Selected)
                    dgvImcId.Rows.RemoveAt(oneCell.RowIndex);
            }
            n--;
        }

        private void btnResetSP_Click(object sender, EventArgs e)
        {
            txtQuantity.Text = null;
            dgvImcId.Rows.Clear();
            btnThem.Enabled = true;
            n = 0;
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (this.dgvImcId.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Không có sản phẩm trong phiếu nhập !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
            else
            {
                foreach (DataGridViewRow dr in dgvImcId.Rows)
                {
                    int idicf = Convert.ToInt32(lbIdPN.Text.ToString());

                    string namesp = dr.Cells[2].Value.ToString();
                    int soluong = Convert.ToInt32(dr.Cells[3].Value.ToString());

                    int idsp = ProductsDAL.Instance.GetIdSP(namesp);

                    int statusCT = 1;

                    ImportCouponInfoDAL.Instance.InsertImportCouponInfoDAL(idicf, soluong, idsp, statusCT);
                }
                MessageBox.Show("Thanh toán phiếu nhập thành công !", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                dgvImcId.Rows.Clear();
                LoadALL();
                frmPhieuNhap pn = new frmPhieuNhap();
                pn.frmPhieuNhap_Load(sender, e);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvImcId_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvImcId.Rows.Count > 0)
            {
                cbProductID.SelectedValue = dgvImcId.CurrentRow.Cells[2].Value.ToString();
                txtQuantity.Text = dgvImcId.CurrentRow.Cells[3].Value.ToString();
            }
        }
        #endregion

    }
}
