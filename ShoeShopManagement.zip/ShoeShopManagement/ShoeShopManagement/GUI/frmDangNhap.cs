﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShoeShopManagement.DAL;


namespace ShoeShopManagement.GUI
{
    public partial class frmDangNhap : Form
    {
        public frmDangNhap()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn thoát chương trình không", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        //Tạo biến để lấy Displayname và ID
        public static string Displayname = "";
        public static string IDAccount = "";

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string userN = txtTK.Text;
                string Pass = txtMK.Text;

                if (Login(userN, Pass))
                {
                    if (AccountDAL.Instance.GetStatusUserByTypeAcc(userN) == 1)
                    {
                        int idU = AccountDAL.Instance.GetIDUserByTypeAcc(userN);
                        string disp = AccountDAL.Instance.GetDisplayUserByTypeAcc(userN);
                        Displayname = disp;
                        IDAccount = idU + "";
                        frmTrangChu frm = new frmTrangChu();
                        this.Hide();
                        frm.HideButtonAdmin();
                        frm.ShowDialog();
                    }
                    else
                    {
                        int idU = AccountDAL.Instance.GetIDUserByTypeAcc(userN);
                        string disp = AccountDAL.Instance.GetDisplayUserByTypeAcc(userN);
                        Displayname = disp;
                        IDAccount = idU + "";
                        frmTrangChu frm = new frmTrangChu();
                        this.Hide();
                        frm.HideButtonStaff();
                        frm.ShowDialog();
                    }

                }
                else if (Pass == "" || userN == "")
                {
                    MessageBox.Show("Không bỏ trống các trường !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("Sai tên tài khoản hoặc mật khẩu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi gì đó !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        bool Login(string userN, string Pass)
        {
            return AccountDAL.Instance.Login(userN, Pass);
        }
    }
}
