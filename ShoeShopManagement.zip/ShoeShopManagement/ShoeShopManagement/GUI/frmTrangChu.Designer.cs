﻿namespace ShoeShopManagement.GUI
{
    partial class frmTrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTrangChu));
            this.btnThoat = new Guna.UI2.WinForms.Guna2Button();
            this.lblIdUser = new System.Windows.Forms.Label();
            this.lblDisplayName = new System.Windows.Forms.Label();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.btnHome = new Guna.UI2.WinForms.Guna2Button();
            this.btnQLKHofNV = new Guna.UI2.WinForms.Guna2Button();
            this.btnTTHoaDon = new Guna.UI2.WinForms.Guna2Button();
            this.btnSubBanHang = new Guna.UI2.WinForms.Guna2Button();
            this.btnDanhMuc = new Guna.UI2.WinForms.Guna2Button();
            this.pnlTrangChuSub = new Guna.UI2.WinForms.Guna2Panel();
            this.btnSubDanhSachPN = new Guna.UI2.WinForms.Guna2Button();
            this.btnSubDanhSachSP = new Guna.UI2.WinForms.Guna2Button();
            this.btnSubDanhMucSP = new Guna.UI2.WinForms.Guna2Button();
            this.btnQuanLy = new Guna.UI2.WinForms.Guna2Button();
            this.pnlDanhMucSub = new Guna.UI2.WinForms.Guna2Panel();
            this.btnSubQLDoanhThu = new Guna.UI2.WinForms.Guna2Button();
            this.btnSubQLNhaCungCap = new Guna.UI2.WinForms.Guna2Button();
            this.btnSubQLKhachHang = new Guna.UI2.WinForms.Guna2Button();
            this.btnSubQLTaiKhoan = new Guna.UI2.WinForms.Guna2Button();
            this.pnlQuanLySub = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.pnlSlideMenu = new System.Windows.Forms.Panel();
            this.lblTime = new System.Windows.Forms.Label();
            this.pnlThoat = new System.Windows.Forms.Panel();
            this.pnlFormChild = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.pnlTrangChuSub.SuspendLayout();
            this.pnlDanhMucSub.SuspendLayout();
            this.pnlQuanLySub.SuspendLayout();
            this.pnlLogo.SuspendLayout();
            this.pnlSlideMenu.SuspendLayout();
            this.pnlThoat.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnThoat
            // 
            this.btnThoat.BorderColor = System.Drawing.Color.White;
            this.btnThoat.CheckedState.Parent = this.btnThoat;
            this.btnThoat.CustomImages.Parent = this.btnThoat;
            this.btnThoat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnThoat.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.White;
            this.btnThoat.HoverState.Parent = this.btnThoat;
            this.btnThoat.Image = ((System.Drawing.Image)(resources.GetObject("btnThoat.Image")));
            this.btnThoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnThoat.ImageSize = new System.Drawing.Size(40, 40);
            this.btnThoat.Location = new System.Drawing.Point(0, 0);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.ShadowDecoration.Parent = this.btnThoat;
            this.btnThoat.Size = new System.Drawing.Size(292, 64);
            this.btnThoat.TabIndex = 0;
            this.btnThoat.Text = "THOÁT";
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // lblIdUser
            // 
            this.lblIdUser.AutoSize = true;
            this.lblIdUser.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdUser.ForeColor = System.Drawing.Color.White;
            this.lblIdUser.Location = new System.Drawing.Point(113, 42);
            this.lblIdUser.Name = "lblIdUser";
            this.lblIdUser.Size = new System.Drawing.Size(21, 14);
            this.lblIdUser.TabIndex = 12;
            this.lblIdUser.Text = "ID";
            // 
            // lblDisplayName
            // 
            this.lblDisplayName.AutoSize = true;
            this.lblDisplayName.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayName.ForeColor = System.Drawing.Color.White;
            this.lblDisplayName.Location = new System.Drawing.Point(113, 9);
            this.lblDisplayName.Name = "lblDisplayName";
            this.lblDisplayName.Size = new System.Drawing.Size(41, 14);
            this.lblDisplayName.TabIndex = 11;
            this.lblDisplayName.Text = "UserN";
            // 
            // picBox
            // 
            this.picBox.Image = ((System.Drawing.Image)(resources.GetObject("picBox.Image")));
            this.picBox.Location = new System.Drawing.Point(0, 0);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(105, 120);
            this.picBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBox.TabIndex = 0;
            this.picBox.TabStop = false;
            // 
            // btnHome
            // 
            this.btnHome.BorderColor = System.Drawing.Color.White;
            this.btnHome.CheckedState.Parent = this.btnHome;
            this.btnHome.CustomImages.Parent = this.btnHome;
            this.btnHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHome.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnHome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.HoverState.Parent = this.btnHome;
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnHome.ImageSize = new System.Drawing.Size(40, 40);
            this.btnHome.Location = new System.Drawing.Point(0, 0);
            this.btnHome.Name = "btnHome";
            this.btnHome.ShadowDecoration.Parent = this.btnHome;
            this.btnHome.Size = new System.Drawing.Size(275, 64);
            this.btnHome.TabIndex = 0;
            this.btnHome.Text = "Trang Chủ";
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnQLKHofNV
            // 
            this.btnQLKHofNV.BorderColor = System.Drawing.Color.White;
            this.btnQLKHofNV.CheckedState.Parent = this.btnQLKHofNV;
            this.btnQLKHofNV.CustomImages.Parent = this.btnQLKHofNV;
            this.btnQLKHofNV.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQLKHofNV.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnQLKHofNV.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLKHofNV.ForeColor = System.Drawing.Color.White;
            this.btnQLKHofNV.HoverState.Parent = this.btnQLKHofNV;
            this.btnQLKHofNV.Image = ((System.Drawing.Image)(resources.GetObject("btnQLKHofNV.Image")));
            this.btnQLKHofNV.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnQLKHofNV.Location = new System.Drawing.Point(0, 80);
            this.btnQLKHofNV.Name = "btnQLKHofNV";
            this.btnQLKHofNV.ShadowDecoration.Parent = this.btnQLKHofNV;
            this.btnQLKHofNV.Size = new System.Drawing.Size(275, 40);
            this.btnQLKHofNV.TabIndex = 4;
            this.btnQLKHofNV.Text = "Quản lý khách hàng";
            this.btnQLKHofNV.Click += new System.EventHandler(this.btnQLKHofNV_Click);
            // 
            // btnTTHoaDon
            // 
            this.btnTTHoaDon.BorderColor = System.Drawing.Color.White;
            this.btnTTHoaDon.CheckedState.Parent = this.btnTTHoaDon;
            this.btnTTHoaDon.CustomImages.Parent = this.btnTTHoaDon;
            this.btnTTHoaDon.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTTHoaDon.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnTTHoaDon.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTHoaDon.ForeColor = System.Drawing.Color.White;
            this.btnTTHoaDon.HoverState.Parent = this.btnTTHoaDon;
            this.btnTTHoaDon.Image = ((System.Drawing.Image)(resources.GetObject("btnTTHoaDon.Image")));
            this.btnTTHoaDon.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTTHoaDon.Location = new System.Drawing.Point(0, 40);
            this.btnTTHoaDon.Name = "btnTTHoaDon";
            this.btnTTHoaDon.ShadowDecoration.Parent = this.btnTTHoaDon;
            this.btnTTHoaDon.Size = new System.Drawing.Size(275, 40);
            this.btnTTHoaDon.TabIndex = 3;
            this.btnTTHoaDon.Text = "Thông tin hóa đơn";
            this.btnTTHoaDon.Click += new System.EventHandler(this.btnTTHoaDon_Click);
            // 
            // btnSubBanHang
            // 
            this.btnSubBanHang.BorderColor = System.Drawing.Color.White;
            this.btnSubBanHang.CheckedState.Parent = this.btnSubBanHang;
            this.btnSubBanHang.CustomImages.Parent = this.btnSubBanHang;
            this.btnSubBanHang.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubBanHang.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubBanHang.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubBanHang.ForeColor = System.Drawing.Color.White;
            this.btnSubBanHang.HoverState.Parent = this.btnSubBanHang;
            this.btnSubBanHang.Image = ((System.Drawing.Image)(resources.GetObject("btnSubBanHang.Image")));
            this.btnSubBanHang.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubBanHang.Location = new System.Drawing.Point(0, 0);
            this.btnSubBanHang.Name = "btnSubBanHang";
            this.btnSubBanHang.ShadowDecoration.Parent = this.btnSubBanHang;
            this.btnSubBanHang.Size = new System.Drawing.Size(275, 40);
            this.btnSubBanHang.TabIndex = 2;
            this.btnSubBanHang.Text = "Bán hàng";
            this.btnSubBanHang.Click += new System.EventHandler(this.btnSubBanHang_Click);
            // 
            // btnDanhMuc
            // 
            this.btnDanhMuc.BorderColor = System.Drawing.Color.White;
            this.btnDanhMuc.CheckedState.Parent = this.btnDanhMuc;
            this.btnDanhMuc.CustomImages.Parent = this.btnDanhMuc;
            this.btnDanhMuc.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDanhMuc.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnDanhMuc.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMuc.ForeColor = System.Drawing.Color.White;
            this.btnDanhMuc.HoverState.Parent = this.btnDanhMuc;
            this.btnDanhMuc.Image = ((System.Drawing.Image)(resources.GetObject("btnDanhMuc.Image")));
            this.btnDanhMuc.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDanhMuc.ImageSize = new System.Drawing.Size(40, 40);
            this.btnDanhMuc.Location = new System.Drawing.Point(0, 184);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.ShadowDecoration.Parent = this.btnDanhMuc;
            this.btnDanhMuc.Size = new System.Drawing.Size(275, 64);
            this.btnDanhMuc.TabIndex = 4;
            this.btnDanhMuc.Text = "Danh Mục";
            this.btnDanhMuc.Click += new System.EventHandler(this.btnDanhMuc_Click);
            // 
            // pnlTrangChuSub
            // 
            this.pnlTrangChuSub.Controls.Add(this.btnQLKHofNV);
            this.pnlTrangChuSub.Controls.Add(this.btnTTHoaDon);
            this.pnlTrangChuSub.Controls.Add(this.btnSubBanHang);
            this.pnlTrangChuSub.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTrangChuSub.Location = new System.Drawing.Point(0, 64);
            this.pnlTrangChuSub.Name = "pnlTrangChuSub";
            this.pnlTrangChuSub.ShadowDecoration.Parent = this.pnlTrangChuSub;
            this.pnlTrangChuSub.Size = new System.Drawing.Size(275, 120);
            this.pnlTrangChuSub.TabIndex = 3;
            // 
            // btnSubDanhSachPN
            // 
            this.btnSubDanhSachPN.BorderColor = System.Drawing.Color.White;
            this.btnSubDanhSachPN.CheckedState.Parent = this.btnSubDanhSachPN;
            this.btnSubDanhSachPN.CustomImages.Parent = this.btnSubDanhSachPN;
            this.btnSubDanhSachPN.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubDanhSachPN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubDanhSachPN.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubDanhSachPN.ForeColor = System.Drawing.Color.White;
            this.btnSubDanhSachPN.HoverState.Parent = this.btnSubDanhSachPN;
            this.btnSubDanhSachPN.Image = ((System.Drawing.Image)(resources.GetObject("btnSubDanhSachPN.Image")));
            this.btnSubDanhSachPN.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubDanhSachPN.Location = new System.Drawing.Point(0, 80);
            this.btnSubDanhSachPN.Name = "btnSubDanhSachPN";
            this.btnSubDanhSachPN.ShadowDecoration.Parent = this.btnSubDanhSachPN;
            this.btnSubDanhSachPN.Size = new System.Drawing.Size(275, 40);
            this.btnSubDanhSachPN.TabIndex = 8;
            this.btnSubDanhSachPN.Text = "Danh sách phiếu nhập";
            this.btnSubDanhSachPN.Click += new System.EventHandler(this.btnSubDanhSachPN_Click);
            // 
            // btnSubDanhSachSP
            // 
            this.btnSubDanhSachSP.BorderColor = System.Drawing.Color.White;
            this.btnSubDanhSachSP.CheckedState.Parent = this.btnSubDanhSachSP;
            this.btnSubDanhSachSP.CustomImages.Parent = this.btnSubDanhSachSP;
            this.btnSubDanhSachSP.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubDanhSachSP.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubDanhSachSP.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubDanhSachSP.ForeColor = System.Drawing.Color.White;
            this.btnSubDanhSachSP.HoverState.Parent = this.btnSubDanhSachSP;
            this.btnSubDanhSachSP.Image = ((System.Drawing.Image)(resources.GetObject("btnSubDanhSachSP.Image")));
            this.btnSubDanhSachSP.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubDanhSachSP.Location = new System.Drawing.Point(0, 40);
            this.btnSubDanhSachSP.Name = "btnSubDanhSachSP";
            this.btnSubDanhSachSP.ShadowDecoration.Parent = this.btnSubDanhSachSP;
            this.btnSubDanhSachSP.Size = new System.Drawing.Size(275, 40);
            this.btnSubDanhSachSP.TabIndex = 3;
            this.btnSubDanhSachSP.Text = "Danh sách sản phẩm";
            this.btnSubDanhSachSP.Click += new System.EventHandler(this.btnSubDanhSachSP_Click);
            // 
            // btnSubDanhMucSP
            // 
            this.btnSubDanhMucSP.BorderColor = System.Drawing.Color.White;
            this.btnSubDanhMucSP.CheckedState.Parent = this.btnSubDanhMucSP;
            this.btnSubDanhMucSP.CustomImages.Parent = this.btnSubDanhMucSP;
            this.btnSubDanhMucSP.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubDanhMucSP.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubDanhMucSP.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubDanhMucSP.ForeColor = System.Drawing.Color.White;
            this.btnSubDanhMucSP.HoverState.Parent = this.btnSubDanhMucSP;
            this.btnSubDanhMucSP.Image = ((System.Drawing.Image)(resources.GetObject("btnSubDanhMucSP.Image")));
            this.btnSubDanhMucSP.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubDanhMucSP.Location = new System.Drawing.Point(0, 0);
            this.btnSubDanhMucSP.Name = "btnSubDanhMucSP";
            this.btnSubDanhMucSP.ShadowDecoration.Parent = this.btnSubDanhMucSP;
            this.btnSubDanhMucSP.Size = new System.Drawing.Size(275, 40);
            this.btnSubDanhMucSP.TabIndex = 2;
            this.btnSubDanhMucSP.Text = "Danh mục sản phẩm";
            this.btnSubDanhMucSP.Click += new System.EventHandler(this.btnSubDanhMucSP_Click);
            // 
            // btnQuanLy
            // 
            this.btnQuanLy.BorderColor = System.Drawing.Color.White;
            this.btnQuanLy.CheckedState.Parent = this.btnQuanLy;
            this.btnQuanLy.CustomImages.Parent = this.btnQuanLy;
            this.btnQuanLy.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQuanLy.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnQuanLy.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLy.ForeColor = System.Drawing.Color.White;
            this.btnQuanLy.HoverState.Parent = this.btnQuanLy;
            this.btnQuanLy.Image = ((System.Drawing.Image)(resources.GetObject("btnQuanLy.Image")));
            this.btnQuanLy.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnQuanLy.ImageSize = new System.Drawing.Size(40, 40);
            this.btnQuanLy.Location = new System.Drawing.Point(0, 368);
            this.btnQuanLy.Name = "btnQuanLy";
            this.btnQuanLy.ShadowDecoration.Parent = this.btnQuanLy;
            this.btnQuanLy.Size = new System.Drawing.Size(275, 64);
            this.btnQuanLy.TabIndex = 19;
            this.btnQuanLy.Text = "Quản Lý";
            this.btnQuanLy.Click += new System.EventHandler(this.btnQuanLy_Click);
            // 
            // pnlDanhMucSub
            // 
            this.pnlDanhMucSub.Controls.Add(this.btnSubDanhSachPN);
            this.pnlDanhMucSub.Controls.Add(this.btnSubDanhSachSP);
            this.pnlDanhMucSub.Controls.Add(this.btnSubDanhMucSP);
            this.pnlDanhMucSub.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDanhMucSub.Location = new System.Drawing.Point(0, 248);
            this.pnlDanhMucSub.Name = "pnlDanhMucSub";
            this.pnlDanhMucSub.ShadowDecoration.Parent = this.pnlDanhMucSub;
            this.pnlDanhMucSub.Size = new System.Drawing.Size(275, 120);
            this.pnlDanhMucSub.TabIndex = 5;
            // 
            // btnSubQLDoanhThu
            // 
            this.btnSubQLDoanhThu.BorderColor = System.Drawing.Color.White;
            this.btnSubQLDoanhThu.CheckedState.Parent = this.btnSubQLDoanhThu;
            this.btnSubQLDoanhThu.CustomImages.Parent = this.btnSubQLDoanhThu;
            this.btnSubQLDoanhThu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubQLDoanhThu.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubQLDoanhThu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubQLDoanhThu.ForeColor = System.Drawing.Color.White;
            this.btnSubQLDoanhThu.HoverState.Parent = this.btnSubQLDoanhThu;
            this.btnSubQLDoanhThu.Image = ((System.Drawing.Image)(resources.GetObject("btnSubQLDoanhThu.Image")));
            this.btnSubQLDoanhThu.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubQLDoanhThu.Location = new System.Drawing.Point(0, 120);
            this.btnSubQLDoanhThu.Name = "btnSubQLDoanhThu";
            this.btnSubQLDoanhThu.ShadowDecoration.Parent = this.btnSubQLDoanhThu;
            this.btnSubQLDoanhThu.Size = new System.Drawing.Size(275, 40);
            this.btnSubQLDoanhThu.TabIndex = 10;
            this.btnSubQLDoanhThu.Text = "Quản lý doanh thu";
            this.btnSubQLDoanhThu.Click += new System.EventHandler(this.btnSubQLDoanhThu_Click);
            // 
            // btnSubQLNhaCungCap
            // 
            this.btnSubQLNhaCungCap.BorderColor = System.Drawing.Color.White;
            this.btnSubQLNhaCungCap.CheckedState.Parent = this.btnSubQLNhaCungCap;
            this.btnSubQLNhaCungCap.CustomImages.Parent = this.btnSubQLNhaCungCap;
            this.btnSubQLNhaCungCap.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubQLNhaCungCap.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubQLNhaCungCap.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubQLNhaCungCap.ForeColor = System.Drawing.Color.White;
            this.btnSubQLNhaCungCap.HoverState.Parent = this.btnSubQLNhaCungCap;
            this.btnSubQLNhaCungCap.Image = ((System.Drawing.Image)(resources.GetObject("btnSubQLNhaCungCap.Image")));
            this.btnSubQLNhaCungCap.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubQLNhaCungCap.Location = new System.Drawing.Point(0, 80);
            this.btnSubQLNhaCungCap.Name = "btnSubQLNhaCungCap";
            this.btnSubQLNhaCungCap.ShadowDecoration.Parent = this.btnSubQLNhaCungCap;
            this.btnSubQLNhaCungCap.Size = new System.Drawing.Size(275, 40);
            this.btnSubQLNhaCungCap.TabIndex = 9;
            this.btnSubQLNhaCungCap.Text = "Quản lý nhà cung cấp";
            this.btnSubQLNhaCungCap.Click += new System.EventHandler(this.btnSubQLNhaCungCap_Click);
            // 
            // btnSubQLKhachHang
            // 
            this.btnSubQLKhachHang.BorderColor = System.Drawing.Color.White;
            this.btnSubQLKhachHang.CheckedState.Parent = this.btnSubQLKhachHang;
            this.btnSubQLKhachHang.CustomImages.Parent = this.btnSubQLKhachHang;
            this.btnSubQLKhachHang.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubQLKhachHang.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubQLKhachHang.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubQLKhachHang.ForeColor = System.Drawing.Color.White;
            this.btnSubQLKhachHang.HoverState.Parent = this.btnSubQLKhachHang;
            this.btnSubQLKhachHang.Image = ((System.Drawing.Image)(resources.GetObject("btnSubQLKhachHang.Image")));
            this.btnSubQLKhachHang.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubQLKhachHang.Location = new System.Drawing.Point(0, 40);
            this.btnSubQLKhachHang.Name = "btnSubQLKhachHang";
            this.btnSubQLKhachHang.ShadowDecoration.Parent = this.btnSubQLKhachHang;
            this.btnSubQLKhachHang.Size = new System.Drawing.Size(275, 40);
            this.btnSubQLKhachHang.TabIndex = 3;
            this.btnSubQLKhachHang.Text = "Quản lý khách hàng";
            this.btnSubQLKhachHang.Click += new System.EventHandler(this.btnSubQLKhachHang_Click);
            // 
            // btnSubQLTaiKhoan
            // 
            this.btnSubQLTaiKhoan.BorderColor = System.Drawing.Color.White;
            this.btnSubQLTaiKhoan.CheckedState.Parent = this.btnSubQLTaiKhoan;
            this.btnSubQLTaiKhoan.CustomImages.Parent = this.btnSubQLTaiKhoan;
            this.btnSubQLTaiKhoan.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSubQLTaiKhoan.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.btnSubQLTaiKhoan.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubQLTaiKhoan.ForeColor = System.Drawing.Color.White;
            this.btnSubQLTaiKhoan.HoverState.Parent = this.btnSubQLTaiKhoan;
            this.btnSubQLTaiKhoan.Image = ((System.Drawing.Image)(resources.GetObject("btnSubQLTaiKhoan.Image")));
            this.btnSubQLTaiKhoan.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubQLTaiKhoan.Location = new System.Drawing.Point(0, 0);
            this.btnSubQLTaiKhoan.Name = "btnSubQLTaiKhoan";
            this.btnSubQLTaiKhoan.ShadowDecoration.Parent = this.btnSubQLTaiKhoan;
            this.btnSubQLTaiKhoan.Size = new System.Drawing.Size(275, 40);
            this.btnSubQLTaiKhoan.TabIndex = 2;
            this.btnSubQLTaiKhoan.Text = "Quản lý tài khoản";
            this.btnSubQLTaiKhoan.Click += new System.EventHandler(this.btnSubQLTaiKhoan_Click);
            // 
            // pnlQuanLySub
            // 
            this.pnlQuanLySub.Controls.Add(this.btnSubQLDoanhThu);
            this.pnlQuanLySub.Controls.Add(this.btnSubQLNhaCungCap);
            this.pnlQuanLySub.Controls.Add(this.btnSubQLKhachHang);
            this.pnlQuanLySub.Controls.Add(this.btnSubQLTaiKhoan);
            this.pnlQuanLySub.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlQuanLySub.Location = new System.Drawing.Point(0, 432);
            this.pnlQuanLySub.Name = "pnlQuanLySub";
            this.pnlQuanLySub.ShadowDecoration.Parent = this.pnlQuanLySub;
            this.pnlQuanLySub.Size = new System.Drawing.Size(275, 160);
            this.pnlQuanLySub.TabIndex = 20;
            // 
            // pnlLogo
            // 
            this.pnlLogo.AutoScroll = true;
            this.pnlLogo.Controls.Add(this.pnlQuanLySub);
            this.pnlLogo.Controls.Add(this.btnQuanLy);
            this.pnlLogo.Controls.Add(this.pnlDanhMucSub);
            this.pnlLogo.Controls.Add(this.btnDanhMuc);
            this.pnlLogo.Controls.Add(this.pnlTrangChuSub);
            this.pnlLogo.Controls.Add(this.btnHome);
            this.pnlLogo.Location = new System.Drawing.Point(0, 120);
            this.pnlLogo.Margin = new System.Windows.Forms.Padding(4);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(292, 408);
            this.pnlLogo.TabIndex = 13;
            // 
            // pnlSlideMenu
            // 
            this.pnlSlideMenu.AutoScroll = true;
            this.pnlSlideMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.pnlSlideMenu.Controls.Add(this.lblTime);
            this.pnlSlideMenu.Controls.Add(this.pnlLogo);
            this.pnlSlideMenu.Controls.Add(this.lblIdUser);
            this.pnlSlideMenu.Controls.Add(this.lblDisplayName);
            this.pnlSlideMenu.Controls.Add(this.picBox);
            this.pnlSlideMenu.Controls.Add(this.pnlThoat);
            this.pnlSlideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSlideMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlSlideMenu.Margin = new System.Windows.Forms.Padding(4);
            this.pnlSlideMenu.MaximumSize = new System.Drawing.Size(292, 600);
            this.pnlSlideMenu.MinimumSize = new System.Drawing.Size(105, 600);
            this.pnlSlideMenu.Name = "pnlSlideMenu";
            this.pnlSlideMenu.Size = new System.Drawing.Size(292, 600);
            this.pnlSlideMenu.TabIndex = 2;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.White;
            this.lblTime.Location = new System.Drawing.Point(113, 75);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(35, 14);
            this.lblTime.TabIndex = 14;
            this.lblTime.Text = "Time";
            // 
            // pnlThoat
            // 
            this.pnlThoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.pnlThoat.Controls.Add(this.btnThoat);
            this.pnlThoat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlThoat.Location = new System.Drawing.Point(0, 536);
            this.pnlThoat.Margin = new System.Windows.Forms.Padding(4);
            this.pnlThoat.Name = "pnlThoat";
            this.pnlThoat.Size = new System.Drawing.Size(292, 64);
            this.pnlThoat.TabIndex = 10;
            // 
            // pnlFormChild
            // 
            this.pnlFormChild.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.pnlFormChild.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlFormChild.Location = new System.Drawing.Point(292, 0);
            this.pnlFormChild.Margin = new System.Windows.Forms.Padding(4);
            this.pnlFormChild.MaximumSize = new System.Drawing.Size(930, 600);
            this.pnlFormChild.MinimumSize = new System.Drawing.Size(930, 600);
            this.pnlFormChild.Name = "pnlFormChild";
            this.pnlFormChild.Size = new System.Drawing.Size(930, 600);
            this.pnlFormChild.TabIndex = 3;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmTrangChu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 600);
            this.Controls.Add(this.pnlSlideMenu);
            this.Controls.Add(this.pnlFormChild);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1222, 600);
            this.MinimumSize = new System.Drawing.Size(1222, 600);
            this.Name = "frmTrangChu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTrangChu";
            this.Load += new System.EventHandler(this.frmTrangChu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.pnlTrangChuSub.ResumeLayout(false);
            this.pnlDanhMucSub.ResumeLayout(false);
            this.pnlQuanLySub.ResumeLayout(false);
            this.pnlLogo.ResumeLayout(false);
            this.pnlSlideMenu.ResumeLayout(false);
            this.pnlSlideMenu.PerformLayout();
            this.pnlThoat.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnThoat;
        private System.Windows.Forms.Label lblIdUser;
        public System.Windows.Forms.Label lblDisplayName;
        private System.Windows.Forms.PictureBox picBox;
        private Guna.UI2.WinForms.Guna2Button btnHome;
        private Guna.UI2.WinForms.Guna2Button btnQLKHofNV;
        private Guna.UI2.WinForms.Guna2Button btnTTHoaDon;
        private Guna.UI2.WinForms.Guna2Button btnSubBanHang;
        private Guna.UI2.WinForms.Guna2Button btnDanhMuc;
        private Guna.UI2.WinForms.Guna2Panel pnlTrangChuSub;
        private Guna.UI2.WinForms.Guna2Button btnSubDanhSachPN;
        private Guna.UI2.WinForms.Guna2Button btnSubDanhSachSP;
        private Guna.UI2.WinForms.Guna2Button btnSubDanhMucSP;
        private Guna.UI2.WinForms.Guna2Button btnQuanLy;
        private Guna.UI2.WinForms.Guna2Panel pnlDanhMucSub;
        private Guna.UI2.WinForms.Guna2Button btnSubQLDoanhThu;
        private Guna.UI2.WinForms.Guna2Button btnSubQLNhaCungCap;
        private Guna.UI2.WinForms.Guna2Button btnSubQLKhachHang;
        private Guna.UI2.WinForms.Guna2Button btnSubQLTaiKhoan;
        private Guna.UI2.WinForms.Guna2Panel pnlQuanLySub;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Panel pnlSlideMenu;
        private System.Windows.Forms.Panel pnlThoat;
        private System.Windows.Forms.Panel pnlFormChild;
        public System.Windows.Forms.Label lblTime;
        public System.Windows.Forms.Timer timer1;
    }
}