﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShoeShopManagement.DAL;
using ShoeShopManagement.GUI;


namespace ShoeShopManagement.GUI
{
    public partial class frmTrangChu : Form
    {
        frmQLTaiKhoan frmTK = new frmQLTaiKhoan();
        frmQLKhachHang frmQLKH = new frmQLKhachHang();
        frmQLNhaCC frmNCC = new frmQLNhaCC();
        frmDanhMucSP frmDM = new frmDanhMucSP();
        frmSanPham frmSP = new frmSanPham();
        frmPhieuNhap frmImport = new frmPhieuNhap();
        frmQLDoanhThu dt = new frmQLDoanhThu();

        public frmTrangChu()
        {
            InitializeComponent();
            Customize();
            LoadLabel();
        }
        public void frmTrangChu_Load(object sender, EventArgs e)
        {
            LoadLabel();
            timer1.Enabled = true;
        }
        public void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToShortDateString() +" "+ DateTime.Now.ToShortTimeString();
        }

        #region Methods
        public void LoadLabel()
        {
            lblDisplayName.Text = "Xin chào : \n" + frmDangNhap.Displayname;
            lblIdUser.Text = "ID : " + frmDangNhap.IDAccount;
        }

        //Hàm này dùng khi mà đăng nhập bằng tài khoản nv sẽ ẩn đi
        public void HideButtonStaff()
        {
            btnDanhMuc.Visible = false;
            pnlDanhMucSub.Visible = false;
            btnQuanLy.Visible = false;
            pnlQuanLySub.Visible = false;
        }
        public void HideButtonAdmin()
        {
            pnlTrangChuSub.Size = new System.Drawing.Size(275, 80);
            btnQLKHofNV.Visible = false;
        }

        private void Customize()
        {
            pnlTrangChuSub.Visible = false;
            pnlDanhMucSub.Visible = false;
            pnlQuanLySub.Visible = false;
        }

        private void HideSubMenu()
        {
            if (pnlTrangChuSub.Visible == true)
            {
                pnlTrangChuSub.Visible = false;
            }
            if (pnlDanhMucSub.Visible == true)
            {
                pnlDanhMucSub.Visible = false;
            }
            if (pnlQuanLySub.Visible == true)
            {
                pnlQuanLySub.Visible = false;
            }
        }

        private void ShowSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                HideSubMenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }




        #endregion

        #region Events
            #region Button Main
        //Button Home
        private void btnHome_Click(object sender, EventArgs e)
        {
            ShowSubMenu(pnlTrangChuSub);
        }
    //Button Danh Muc
    private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            ShowSubMenu(pnlDanhMucSub);
        }
    //Button Quan Ly
    private void btnQuanLy_Click(object sender, EventArgs e)
        {
            ShowSubMenu(pnlQuanLySub);
        }
    //Button Thoát
    private void btnThoat_Click(object sender, EventArgs e)
        {
            frmDangNhap frm = new frmDangNhap();
            this.Close();
            this.Hide();
            frm.ShowDialog();
        }
        #endregion

        #region Button Child
        //Sub of Button Trang Chủ
        private void btnSubBanHang_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(frmDangNhap.IDAccount);
            frmBanHang frmBanHang = new frmBanHang(id);

            frmBanHang.frmBanHang_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmBanHang.TopLevel = false;
            pnlFormChild.Controls.Add(frmBanHang);
            frmBanHang.Dock = DockStyle.Fill;
            frmBanHang.Show();
        }

        private void btnTTHoaDon_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(frmDangNhap.IDAccount);
            frmHoaDon hd = new frmHoaDon(id);

            hd.frmHoaDon_Load(sender, e);

            pnlFormChild.Controls.Clear();
            hd.TopLevel = false;
            pnlFormChild.Controls.Add(hd);
            hd.Dock = DockStyle.Fill;
            hd.Show();
        }

        private void btnQLKHofNV_Click(object sender, EventArgs e)
        {
            frmQLKH.frmQLKhachHang_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmQLKH.TopLevel = false;
            pnlFormChild.Controls.Add(frmQLKH);
            frmQLKH.Dock = DockStyle.Fill;
            frmQLKH.Show();
        }

        //Sub of Button Danh Muc
        private void btnSubDanhMucSP_Click(object sender, EventArgs e)
        {
            frmDM.frmDanhMucSP_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmDM.TopLevel = false;
            pnlFormChild.Controls.Add(frmDM);
            frmDM.Dock = DockStyle.Fill;
            frmDM.Show();
        }

        private void btnSubDanhSachSP_Click(object sender, EventArgs e)
        {
            frmSP.frmSanPham_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmSP.TopLevel = false;
            pnlFormChild.Controls.Add(frmSP);
            frmSP.Dock = DockStyle.Fill;
            frmSP.Show();
        }

        private void btnSubDanhSachPN_Click(object sender, EventArgs e)
        {
            frmImport.frmPhieuNhap_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmImport.TopLevel = false;
            pnlFormChild.Controls.Add(frmImport);
            frmImport.Dock = DockStyle.Fill;
            frmImport.Show();
        }

        //Sub of Button Quản Lý
        private void btnSubQLTaiKhoan_Click(object sender, EventArgs e)
        {
            frmTK.frmQLTaiKhoan_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmTK.TopLevel = false;
            pnlFormChild.Controls.Add(frmTK);
            frmTK.Dock = DockStyle.Fill;
            frmTK.Show();
        }

        private void btnSubQLKhachHang_Click(object sender, EventArgs e)
        {
            frmQLKH.frmQLKhachHang_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmQLKH.TopLevel = false;
            pnlFormChild.Controls.Add(frmQLKH);
            frmQLKH.Dock = DockStyle.Fill;
            frmQLKH.Show();
        }

        private void btnSubQLNhaCungCap_Click(object sender, EventArgs e)
        {
            frmNCC.frmQLNhaCC_Load(sender, e);

            pnlFormChild.Controls.Clear();
            frmNCC.TopLevel = false;
            pnlFormChild.Controls.Add(frmNCC);
            frmNCC.Dock = DockStyle.Fill;
            frmNCC.Show();
        }

        private void btnSubQLDoanhThu_Click(object sender, EventArgs e)
        {
            dt.frmQLDoanhThu_Load(sender, e);

            pnlFormChild.Controls.Clear();
            dt.TopLevel = false;
            pnlFormChild.Controls.Add(dt);
            dt.Dock = DockStyle.Fill;
            dt.Show();
        }
        #endregion
        #endregion


    }
}
