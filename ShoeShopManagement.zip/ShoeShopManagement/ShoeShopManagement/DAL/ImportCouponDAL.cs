﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoeShopManagement.DTO;
using System.Data.SqlClient;

namespace ShoeShopManagement.DAL
{
    public class ImportCouponDAL
    {
        //Cau hinh Singleton
        private static ImportCouponDAL instance;

        public static ImportCouponDAL Instance
        {
            get { if (instance == null) instance = new ImportCouponDAL(); return instance; }
            private set { instance = value; }
        }

        private ImportCouponDAL() { }
        //Cau hinh Singleton

        public int GetIdPN(int id)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblImportCoupon where ImcId =" + id);
            if (dt.Rows.Count > 0)
            {
                ImportCoupon IDd = new ImportCoupon(dt.Rows[0]);
                return IDd.ImcId;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        public DataTable GetListPNCT(int id)
        {
            try
            {
                SqlConnection conn = DataProvider.Instance.OpenKN();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ListOfDSPN";
                cmd.Parameters.AddWithValue("id", id);
                DataTable data = new DataTable();
                data.Load(cmd.ExecuteReader());
                return data;
            }
            finally
            {
                DataProvider.Instance.CloseKN();
            }
        }

        //Load acc
        public DataTable GetImportCouponDel()
        {
            return DataProvider.Instance.ExQuery("Exec USP_GetImportCouponDel");
        }

        public DataTable GetImportCoupon()
        {
            return DataProvider.Instance.ExQuery("Exec USP_GetImportCoupon");
        }

        public bool InsertImportCoupon(DateTime? date, int supid, int usid, int type, int status)
        {
            string qr = string.Format("USP_InsertImportCoupon @date , @supid , @usid , @type , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { date, supid, usid, type, status });
            return res.Rows.Count > 0;
        }

        public bool UpdateImportCoupon(DateTime? date, int supid, int usid, int idPN)
        {
            string qr = string.Format("USP_UpdateImportCoupon @date , @supid , @usid , @id");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { date, supid, usid, idPN });
            return res.Rows.Count > 0;
        }

        public bool DelImportCoupon(int id)
        {
            string qr = string.Format("USP_DelImportCoupon @id");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { id });
            return res.Rows.Count > 0;
        }
    }
}
