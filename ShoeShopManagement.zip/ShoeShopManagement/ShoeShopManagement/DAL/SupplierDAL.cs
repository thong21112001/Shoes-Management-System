﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoeShopManagement.DTO;
using System.Data;
using System.Data.SqlClient;

namespace ShoeShopManagement.DAL
{
    public class SupplierDAL
    {
        //Cau hinh Singleton
        private static SupplierDAL instance;

        public static SupplierDAL Instance
        {
            get { if (instance == null) instance = new SupplierDAL(); return instance; }
            private set { instance = value; }
        }

        private SupplierDAL() { }
        //Cau hinh Singleton

        //Load acc
        public DataTable GetSupplierDel()
        {
            return DataProvider.Instance.ExQuery("Exec USP_GetListSupplierDel");
        }

        public DataTable GetSupplier()
        {
            return DataProvider.Instance.ExQuery("Exec USP_GetListSupplier");
        }

        public bool InsertSupplier(string name, string diachi, string sdt, string Email, int status)
        {
            string qr = string.Format("USP_InsertSupplier @name , @diachi , @sdt , @email , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { name, diachi, sdt, Email, status });
            return res.Rows.Count > 0;
        }

        public bool UpdateSupplier(int id, string name, string diachi, string sdt, string Email)
        {
            string qr = string.Format("USP_UpdateSupplier @name , @diachi , @sdt , @email , @id");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { name, diachi, sdt, Email, id });
            return res.Rows.Count > 0;
        }

        public bool DelSupplier(int id)
        {
            string qr = string.Format("USP_DelSupplier @id");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { id });
            return res.Rows.Count > 0;
        }

        public DataTable SearchSupplier(string name)
        {
            string qr = "Exec USP_SearcSupplier @name = N'" + name + "'";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public int GetTotalSupplier()
        {
            try
            {
                return (int)DataProvider.Instance.ExScarlar("Exec GetTotalSupplier");
            }
            catch (Exception)
            {
                return 1;
            }
        }

        public bool PhucHoi(string phone)
        {
            string qr = string.Format("USP_PhucHoiNCC @phone");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { phone });
            return res.Rows.Count > 0;
        }
        public string GetSDT(string phone)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from tblSupplier Where PhoneNumber = N'" + phone + "' ");
            if (dt.Rows.Count > 0)
            {
                Supplier sup = new Supplier(dt.Rows[0]);
                return sup.PhoneNumber;
            }
            //Id bang -1 thi khong co
            return "";
        }
    }
}
