﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoeShopManagement.DTO;
using System.Data;
using System.Data.SqlClient;

namespace ShoeShopManagement.DAL
{
    public class CategoryDAL
    {
        //Cau hinh Singleton
        private static CategoryDAL instance;

        public static CategoryDAL Instance
        {
            get { if (instance == null) instance = new CategoryDAL(); return instance; }
            private set { instance = value; }
        }

        private CategoryDAL() { }
        //Cau hinh Singleton
        public int GetIDCate(int id)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblCategory Where CateId = " + id);
            if (dt.Rows.Count > 0)
            {
                Category ID = new Category(dt.Rows[0]);
                return ID.CateId;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        public DataTable ListOfCategoryDel()
        {
            string qr = "Exec USP_ListOfCategoryDel";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public DataTable ListOfCategory()
        {
            string qr = "Exec USP_ListOfCategory";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public bool InsertCate(string nameCate,int statusCate)
        {
            string qr = string.Format("Insert into dbo.tblCategory(NameCate,Status) Values (N'{0}',{1})", nameCate, statusCate);
            //neu nhu co 1 dong dc insert thi la thanh cong
            int res = DataProvider.Instance.ExNonQuery(qr);
            return res > 0;
        }

        public bool UpdateCate(string nameCate, int idCate)
        {
            string qr = string.Format("Update dbo.tblCategory set NameCate = N'{0}' where CateId = {1}", nameCate, idCate);
            //neu nhu co 1 dong dc insert thi la thanh cong
            int res = DataProvider.Instance.ExNonQuery(qr);
            return res > 0;
        }

        public bool DelCate(int idCate)
        {
            string qr = string.Format("Exec USP_DelCate @idCate = " + idCate);
            //neu nhu co 1 dong dc insert thi la thanh cong
            int res = DataProvider.Instance.ExNonQuery(qr);
            return res > 0;
        }

        public DataTable SearchCate(string name)
        {
            string qr = "Exec USP_SearchCate @name = N'" + name + "'";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public bool PhucHoi(int id)
        {
            string qr = string.Format("USP_PhucHoiCate @id");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { id });
            return res.Rows.Count > 0;
        }
    }
}
