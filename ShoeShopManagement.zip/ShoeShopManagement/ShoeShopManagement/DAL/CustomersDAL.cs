﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoeShopManagement.DTO;
using System.Data;
using System.Data.SqlClient;

namespace ShoeShopManagement.DAL
{
    public class CustomersDAL
    {
        //Cau hinh Singleton
        private static CustomersDAL instance;

        public static CustomersDAL Instance
        {
            get { if (instance == null) instance = new CustomersDAL(); return instance; }
            private set { instance = value; }
        }

        private CustomersDAL() { }
        //Cau hinh Singleton


        public string GetSDT(string phone)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from tblCustomer Where PhoneNumber = N'" + phone + "' ");
            if (dt.Rows.Count > 0)
            {
                Customer cus = new Customer(dt.Rows[0]);
                return cus.PhoneNumber;
            }
            //Id bang -1 thi khong co
            return "";
        }

        //Load acc
        public DataTable GetCustomersDel()
        {
            return DataProvider.Instance.ExQuery("Exec USP_GetListCusDel");
        }

        public DataTable GetCustomers()
        {
            return DataProvider.Instance.ExQuery("Exec USP_GetListCus");
        }

        public bool InsertCustomers(string nameKH, string diachi, string sdt, int status)
        {
            string qr = string.Format("USP_InsertCustomers @name , @diachi , @sdt , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { nameKH, diachi, sdt, status });
            return res.Rows.Count > 0;
        }

        public bool UpdateCustomers(int id, string nameKH, string sdt, string diachi)
        {
            string qr = string.Format("USP_UpdateCustomers @name , @diachi , @sdt , @idCus");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { nameKH, diachi, sdt, id });
            return res.Rows.Count > 0;
        }

        public bool DelCustomers(int id)
        {
            string qr = string.Format("USP_DelCustomers @idCus");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { id });
            return res.Rows.Count > 0;
        }

        public DataTable SearchCustomers(string name)
        {
            string qr = "Exec USP_SearcCustomers @name = N'" + name + "'";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public bool PhucHoiKH(string id)
        {
            string qr = string.Format("USP_PhucHoiKhachHang @phone");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { id });
            return res.Rows.Count > 0;
        }

        //Load lên cbbox
        public string[] ListCustomerIdName()
        {
            try
            {
                SqlConnection conn = DataProvider.Instance.OpenKN();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ListCustomerIdName";
                List<string> list = new List<string>();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(reader[0].ToString());
                }
                return list.ToArray();
            }
            finally
            {
                DataProvider.Instance.CloseKN();
            }
        }

        public int GetTotalCustomer()
        {
            try
            {
                return (int)DataProvider.Instance.ExScarlar("Exec GetTotalCustomer");
            }
            catch (Exception)
            {
                return 1;
            }
        }
    }
}
