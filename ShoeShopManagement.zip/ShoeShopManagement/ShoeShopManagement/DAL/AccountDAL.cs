﻿using ShoeShopManagement.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using ShoeShopManagement.DTO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Drawing;

namespace ShoeShopManagement.DAL
{
    public class AccountDAL
    {
        //Cau hinh Singleton
        private static AccountDAL instance;

        public static AccountDAL Instance
        {
            get { if (instance == null) instance = new AccountDAL(); return instance; }
            private set { instance = value; }
        }

        private AccountDAL() { }
        //Cau hinh Singleton

        public int GetStatusUserByTypeAccHoaDon(int id)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblAccount where UsId = " + id);
            if (dt.Rows.Count > 0)
            {
                Account userID = new Account(dt.Rows[0]);
                return userID.TypeAccount;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        public string GetEmail(string email)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblAccount Where Email = N'" + email + "' ");
            if (dt.Rows.Count > 0)
            {
                Account userID = new Account(dt.Rows[0]);
                return userID.Email;
            }
            //Id bang -1 thi khong co
            return "";
        }

        public int GetStatusUserByTypeAcc(string username)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblAccount where UserName = N'" + username + "' ");
            if (dt.Rows.Count > 0)
            {
                Account userID = new Account(dt.Rows[0]);
                return userID.TypeAccount;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        public string GetDisplayUserByTypeAcc(string username)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblAccount where UserName = N'" + username + "' ");
            if (dt.Rows.Count > 0)
            {
                Account userID = new Account(dt.Rows[0]);
                return userID.DisplayName;
            }
            //Id bang -1 thi khong co
            return "";
        }

        public int GetIDUserByTypeAcc(string username)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblAccount where UserName = N'" + username + "' ");
            if (dt.Rows.Count > 0)
            {
                Account userID = new Account(dt.Rows[0]);
                return userID.UsId;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        //Check login
        public bool Login(string userN, string Pass)
        {
            //Su dung StoProc + parameter de tranh loi SQL Injection
            //@usern , @Pass //cach ra de tranh loi
            string query = "USP_AccountLogin @usname , @Pass";
            DataTable result = DataProvider.Instance.ExQuery(query, new object[] { userN, Pass });
            return result.Rows.Count > 0;
        }

        //Load acc
        public DataTable GetAccDel()
        {
            return DataProvider.Instance.ExQuery("USP_GetListUserDel");
        }

        public DataTable GetAcc()
        {
            return DataProvider.Instance.ExQuery("USP_GetListUser");
        }

        public bool InsertUser(string usern, string pass, int type, string display, string email, int status)
        {
            string qr = string.Format("USP_InsertUser @name , @pass , @Type , @displayN , @email , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { usern, pass, type, display, email, status });
            return res.Rows.Count > 0;
        }

        public bool UpdateUser(int id, string usern, string pass, int type, string display, string email)
        {
            string qr = string.Format("USP_UpdateUser @name , @pass , @Type , @displayN , @email , @idU");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { usern, pass, type, display, email, id });
            return res.Rows.Count > 0;
        }

        public bool DelUser(int idU)
        {
            string qr = string.Format("USP_DelUser @idU");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { idU });
            return res.Rows.Count > 0;
        }

        public DataTable SearchAcc(string name)
        {
            string qr = "Exec USP_SearchAcc @name = N'" + name + "'";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public bool PhucHoi(string email)
        {
            string qr = string.Format("USP_PhucHoiTaiKhoan @name");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { email });
            return res.Rows.Count > 0;
        }

        //Load lên cbbox

        public string GetEmployeeIdName(int id)
        {
            try
            {
                SqlConnection conn = DataProvider.Instance.OpenKN();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GetEmployeeIdName";
                cmd.Parameters.AddWithValue("idus", id);
                return Convert.ToString(cmd.ExecuteScalar());
            }
            finally
            {
                DataProvider.Instance.CloseKN();
            }
        }
    }
}
