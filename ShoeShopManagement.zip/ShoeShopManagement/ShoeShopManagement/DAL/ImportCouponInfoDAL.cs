﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoeShopManagement.DTO;
using System.Data;
using System.Data.SqlClient;

namespace ShoeShopManagement.DAL
{
    public class ImportCouponInfoDAL
    {
        //Cau hinh Singleton
        private static ImportCouponInfoDAL instance;

        public static ImportCouponInfoDAL Instance
        {
            get { if (instance == null) instance = new ImportCouponInfoDAL(); return instance; }
            private set { instance = value; }
        }

        private ImportCouponInfoDAL() { }
        //Cau hinh Singleton

        public bool InsertImportCouponInfoDAL(int imcid, int quantity, int prodid, int status)
        {
            //Dùng Insert thường sẽ lỗi nên dùng Procedure để tránh lỗi, cách ra mỗi cái để tránh lỗi
            string qr = string.Format("Exec USP_InsertImportCouponInfo @imcid , @quantity , @prodid , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { imcid, quantity, prodid, status });
            return res.Rows.Count > 0;
        }
    }
}
