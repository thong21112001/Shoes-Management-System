﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoeShopManagement.DAL
{
    internal class DataProvider
    {
        //Tao lop Singleton tu DataProvider bang 3 cau lenh duoi
        //The hien ton tai duy nhat trong chuong trinh
        private static DataProvider instance;//Dong goi Ctrl + R + E

        public static DataProvider Instance
        {
            get { if (instance == null) instance = new DataProvider(); return DataProvider.instance; }
            private set { DataProvider.instance = value; }
        }

        private DataProvider() { }



        private string ckn = @"Data Source=.;Initial Catalog=ShoesManagement;Integrated Security=True";

        public SqlConnection OpenKN()
        {
            SqlConnection con = new SqlConnection(ckn);
            con.Open();
            return con;
        }

        public SqlConnection CloseKN()
        {
            SqlConnection con = new SqlConnection(ckn);
            con.Close();
            return con;
        }

        //Tra ve du lieu dang bang
        public DataTable ExQuery(string qr, object[] parameter = null)
        {
            DataTable dt = new DataTable();
            //Du lieu trong con se tu giai phong
            using (SqlConnection con = new SqlConnection(ckn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(qr, con);

                if (parameter != null)
                {
                    string[] lisPa = qr.Split(' ');
                    int i = 0;
                    foreach (string item in lisPa)
                    {
                        if (item.Contains('@'))
                        {
                            cmd.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                con.Close();
            }
            return dt;
        }

        //Tra ve so dong thanh cong
        public int ExNonQuery(string qr, object[] parameter = null)
        {
            int dt = 0;
            //Du lieu trong con se tu giai phong
            using (SqlConnection con = new SqlConnection(ckn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(qr, con);

                if (parameter != null)
                {
                    string[] lisPa = qr.Split(' ');
                    int i = 0;
                    foreach (string item in lisPa)
                    {
                        if (item.Contains('@'))
                        {
                            cmd.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }
                dt = cmd.ExecuteNonQuery();
                con.Close();
            }
            return dt;
        }

        //So luong tra ve
        public object ExScarlar(string qr, object[] parameter = null)
        {
            object dt = 0;
            //Du lieu trong con se tu giai phong
            using (SqlConnection con = new SqlConnection(ckn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(qr, con);

                if (parameter != null)
                {
                    string[] lisPa = qr.Split(' ');
                    int i = 0;
                    foreach (string item in lisPa)
                    {
                        if (item.Contains('@'))
                        {
                            cmd.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }
                dt = cmd.ExecuteScalar();
                con.Close();
            }
            return dt;
        }
    }
}
