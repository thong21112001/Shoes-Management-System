﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ShoeShopManagement.DTO;
using System.Drawing;

namespace ShoeShopManagement.DAL
{
    public class BillDAL
    {
        //Cau hinh Singleton
        private static BillDAL instance;

        public static BillDAL Instance
        {
            get { if (instance == null) instance = new BillDAL(); return instance; }
            private set { instance = value; }
        }

        private BillDAL() { }
        //Cau hinh Singleton
        public DataTable GetTotalDate(string checkin, string checkout)
        {
            return DataProvider.Instance.ExQuery("Exec GetTotalDate @checkin , @checkout", new object[] { checkin, checkout });
        }

        public DataTable Get7Date(string checkin, string checkout)
        {
            return DataProvider.Instance.ExQuery("Exec Get7Date @checkin , @checkout", new object[] { checkin, checkout });
        }

        public DataTable GetListBillByDate(string checkin, string checkout)
        {
            return DataProvider.Instance.ExQuery("Exec GetListBillByDate @checkin , @checkout", new object[] { checkin, checkout });
        }

        public DataTable GetListBill(string checkin)
        {
            return DataProvider.Instance.ExQuery("Exec GetListBill @checkin", new object[] { checkin });
        }

        public DataTable SearchCustomerInBill(string name)
        {
            try
            {
                SqlConnection conn = DataProvider.Instance.OpenKN();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SearchCustomerInBill";
                cmd.Parameters.AddWithValue("name", name);
                DataTable data = new DataTable();
                data.Load(cmd.ExecuteReader());
                return data;
            }
            finally
            {
                DataProvider.Instance.CloseKN();
            }
        }

        public DataTable GetBill()
        {
            return DataProvider.Instance.ExQuery("ListOfBills");
        }

        public bool InsertBill(int usid,int cusid, DateTime? dateTT, float total, int status)
        {
            string qr = string.Format("USP_InsertBill @usid , @cusid , @dateTT , @total , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { usid, cusid, dateTT, total, status });
            return res.Rows.Count > 0;
        }

        public bool DelBill(int id)
        {
            string qr = string.Format("Exec USP_DelBill @id = " + id);
            //neu nhu co 1 dong dc insert thi la thanh cong
            int res = DataProvider.Instance.ExNonQuery(qr);
            return res > 0;
        }

        //Lấy id max trong Bill
        public int GetMaxIdBill()
        {
            try
            {
                return (int)DataProvider.Instance.ExScarlar("Select Max(BillId) from dbo.tblBill");
            }
            catch (Exception)
            {
                return 1;
            }
        }

        public double GetSumToTalBill()
        {
            try
            {
                return (double)DataProvider.Instance.ExScarlar("Exec GetTotalPrice");
            }
            catch (Exception)
            {
                return 1;
            }
        }
    }
}
