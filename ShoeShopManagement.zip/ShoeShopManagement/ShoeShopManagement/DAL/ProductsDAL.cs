﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoeShopManagement.DTO;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace ShoeShopManagement.DAL
{
    public class ProductsDAL
    {
        //Cau hinh Singleton
        private static ProductsDAL instance;

        public static ProductsDAL Instance
        {
            get { if (instance == null) instance = new ProductsDAL(); return instance; }
            private set { instance = value; }
        }

        private ProductsDAL() { }
        //Cau hinh Singleton

        //Lấy name sp từ cb box đẩy lên txtbox số lượng trong bán hàng
        public double GetUnitPrice(string name)
        {
            try
            {
                SqlConnection conn = DataProvider.Instance.OpenKN();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GetUnitPrice";
                cmd.Parameters.AddWithValue("name", name);
                return Convert.ToDouble(cmd.ExecuteScalar());
            }
            finally
            {
                DataProvider.Instance.CloseKN();
            }
        }

        public int GetQuanTitySP(int id)
        {
            string qr = string.Format("USP_GetQuantitySP @idSP");
            DataTable dt = DataProvider.Instance.ExQuery(qr, new object[] { id });
            if (dt.Rows.Count > 0)
            {
                Product IDProd = new Product(dt.Rows[0]);
                return IDProd.Quantity;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        public int GetIdSP(string name)
        {
            string qr = string.Format("USP_GetIdSP @name");
            DataTable dt = DataProvider.Instance.ExQuery(qr, new object[] { name });
            if (dt.Rows.Count > 0)
            {
                Product IDProd = new Product(dt.Rows[0]);
                return IDProd.ProdId;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        public int GetIdProduct(int id)
        {
            DataTable dt = DataProvider.Instance.ExQuery("Select * from dbo.tblProduct where ProdId =" + id);
            if (dt.Rows.Count > 0)
            {
                Product IDProd = new Product(dt.Rows[0]);
                return IDProd.ProdId;
            }
            //Id bang -1 thi khong co
            return -1;
        }

        //Frm San Pham
        public DataTable ListOfProductDel()
        {
            string qr = "Exec USP_ListOfProductDel";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public DataTable ListOfProduct()
        {
            string qr = "Exec USP_ListOfProduct";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        public bool InsertProduct(string nameSP, double price, byte[] image, int idcate, int idSup, int quantity, int status)
        {
            //Dùng Insert thường sẽ lỗi nên dùng Procedure để tránh lỗi, cách ra mỗi cái để tránh lỗi
            string qr = string.Format("USP_InsertProduct @name , @price , @image , @cateId , @SupId , @quantity , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { nameSP, price, image, idcate, idSup, quantity, status });
            return res.Rows.Count > 0;
        }

        public bool UpdateProduct(string nameSP, double price, byte[] image, int idcate, int idSup, int Id)
        {
            string qr = string.Format("USP_UpdateProduct @name , @price , @image , @cateId , @SupId , @idP ");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { nameSP, price, image, idcate, idSup, Id });
            return res.Rows.Count > 0;
        }

        public bool DelProduct(int Id)
        {
            string qr = string.Format("USP_DelProduct @idP");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { Id });
            return res.Rows.Count > 0;
        }

        public DataTable SearchProducts(string name)
        {
            string qr = "Exec USP_SearchProducts @name = N'" + name + "'";
            DataTable dt = DataProvider.Instance.ExQuery(qr);
            return dt;
        }

        //Load lên cbbox
        public string[] ListProductNameQuantity()
        {
            try
            {
                SqlConnection conn = DataProvider.Instance.OpenKN();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ListProductNameQuantity";
                List<string> list = new List<string>();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(reader[0].ToString());
                }
                return list.ToArray();
            }
            finally
            {
                DataProvider.Instance.CloseKN();
            }
        }

        public bool PhucHoi(int id)
        {
            string qr = string.Format("USP_PhucHoiSP @id");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { id });
            return res.Rows.Count > 0;
        }
    }
}
