﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoeShopManagement.DTO;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace ShoeShopManagement.DAL
{
    public class BillInfoDAL
    {
        //Cau hinh Singleton
        private static BillInfoDAL instance;

        public static BillInfoDAL Instance
        {
            get { if (instance == null) instance = new BillInfoDAL(); return instance; }
            private set { instance = value; }
        }

        private BillInfoDAL() { }
        //Cau hinh Singleton

        public bool InsertBillInfo(int idBill, int proid, int quantity, float price, int status)
        {
            string qr = string.Format("USP_InsertBillInfo @idBill , @proid , @quantity , @price , @status");
            //neu nhu co 1 dong dc insert thi la thanh cong
            DataTable res = DataProvider.Instance.ExQuery(qr, new object[] { idBill, proid, quantity, price, status });
            return res.Rows.Count > 0;
        }

        public DataTable GetBillCT(int id)
        {
            try
            {
                SqlConnection conn = DataProvider.Instance.OpenKN();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ListOfCTBillInfo";
                cmd.Parameters.AddWithValue("id", id);
                DataTable data = new DataTable();
                data.Load(cmd.ExecuteReader());
                return data;
            }
            finally
            {
                DataProvider.Instance.CloseKN();
            }
        }

        public int GetTotalShoes()
        {
            try
            {
                return (int)DataProvider.Instance.ExScarlar("Exec GetTotalShoes");
            }
            catch (Exception)
            {
                return 1;
            }
        }
    }
}
